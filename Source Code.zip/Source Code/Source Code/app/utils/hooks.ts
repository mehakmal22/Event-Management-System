import type { SerializeFrom } from "@remix-run/node";
import { useRouteLoaderData } from "@remix-run/react";
import type { loader as organizerLoaderData } from "~/routes/organizer+/_layout";

export function useOrganizerLoaderData() {
  return useRouteLoaderData("routes/organizer+/_layout") as SerializeFrom<
    typeof organizerLoaderData
  >;
}
