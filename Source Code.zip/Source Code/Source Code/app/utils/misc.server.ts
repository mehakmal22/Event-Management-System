import { json } from "@remix-run/node";
import bcrypt from "bcryptjs";

const DEFAULT_REDIRECT = "/";

// biome-ignore lint/suspicious/noExplicitAny: <explanation>
export const badRequest = <T = any>(data: T) => json<T>(data, { status: 400 });
// biome-ignore lint/suspicious/noExplicitAny: <explanation>
export const unauthorized = <T = any>(data: T) =>
  json<T>(data, { status: 401 });
// biome-ignore lint/suspicious/noExplicitAny: <explanation>
export const forbidden = <T = any>(data: T) => json<T>(data, { status: 403 });
// biome-ignore lint/suspicious/noExplicitAny: <explanation>
export const notFound = <T = any>(data: T) => json<T>(data, { status: 404 });

export function validateEmail(email: unknown): email is string {
  return typeof email === "string" && email.length > 3 && email.includes("@");
}

export function validateName(name: unknown): name is string {
  return typeof name === "string" && name.length > 1;
}

/**
 * This should be used any time the redirect path is user-provided
 * (Like the query string on our login/signup pages). This avoids
 * open-redirect vulnerabilities.
 * @param {string} to The redirect destination
 * @param {string} defaultRedirect The redirect to use if the to is unsafe.
 */
export function safeRedirect(
  to: FormDataEntryValue | null | string | undefined,
  defaultRedirect: string = DEFAULT_REDIRECT,
) {
  if (!to || typeof to !== "string") {
    return defaultRedirect;
  }

  if (!to.startsWith("/") || to.startsWith("//")) {
    return defaultRedirect;
  }

  return to;
}

export function createPasswordHash(password: string) {
  return bcrypt.hash(password, 10);
}
