import { convertToDateTime, toFixedDate } from "~/utils/helpers";

type ValidationReturnType =
  | {
      success: false;
      error: string;
    }
  | {
      success: true;
    };

type ITs = {
  title: string;
  description: string;
  date: Date;
  startTime: string;
  endTime: string;
  speakerName: string;
};

export function useValidateSession() {
  const validateLocalSession = <
    T extends Pick<ITs, "date" | "startTime" | "endTime">,
  >(
    sessionToValidate: Pick<ITs, "date" | "startTime" | "endTime">,
    sessions: Array<T>,
  ): ValidationReturnType => {
    for (const session of sessions) {
      console.log("Existing Session date (string):", session.date);
      console.log("Adding Session date (string):", sessionToValidate.date);

      const existingDate = new Date(session.date);
      const newDate = new Date(sessionToValidate.date);

      console.log("Existing Session date (parsed):", existingDate);
      console.log("Adding Session date (parsed):", newDate);
      console.log("Existing Session timestamp:", existingDate.getTime());
      console.log("Adding Session timestamp:", newDate.getTime());

      if (existingDate.getTime() !== newDate.getTime()) {
        console.log("Dates are different");
        continue; // Skip to next session if dates are different
      }
      console.log("Dates are the same");

      const startTime = toFixedDate(
        convertToDateTime(sessionToValidate.startTime),
      );
      const endTime = toFixedDate(convertToDateTime(sessionToValidate.endTime)); // Fixed: use endTime

      console.log("Adding Session startTime", startTime);
      console.log("Adding Session endTime", endTime);

      const sessionStartTime = new Date(session.startTime);
      const sessionEndTime = new Date(session.endTime);

      console.log("Existing Session startTime", sessionStartTime);
      console.log("Existing Session endTime", sessionEndTime);

      if (
        (startTime.getTime() >= sessionStartTime.getTime() &&
          startTime.getTime() < sessionEndTime.getTime()) ||
        (endTime.getTime() > sessionStartTime.getTime() &&
          endTime.getTime() <= sessionEndTime.getTime()) ||
        (startTime.getTime() <= sessionStartTime.getTime() &&
          endTime.getTime() >= sessionEndTime.getTime())
      ) {
        return {
          success: false,
          error: "Session conflicts with existing session",
        };
      }
    }
    return {
      success: true,
    };
  };

  const validateSession = (session: ITs): ValidationReturnType => {
    const { title, description, startTime, endTime } = session;
    if (!title || !description || !startTime || !endTime) {
      return {
        success: false,
        error: "All fields are required",
      };
    }

    const _startTime = toFixedDate(convertToDateTime(startTime));
    const _endTime = toFixedDate(convertToDateTime(endTime));

    if (_startTime.getTime() >= _endTime.getTime()) {
      return {
        success: false,
        error: "Start time must be less than end time",
      };
    }

    return {
      success: true,
    };
  };

  return {
    validateLocalSession,
    validateSession,
  };
}
