import { useRouteLoaderData, useSubmit } from "@remix-run/react";
import type { RootLoaderData } from "~/root";
import { UserRole } from "~/utils/prisma-enums";

export function useOptionalUser() {
  const data = useRouteLoaderData("root") as RootLoaderData;

  if (Object.values(data).every((v) => v === null)) {
    return null;
  }

  if (data.admin) {
    return {
      id: data.admin.id,
      name: `${data.admin.firstName} ${data.admin.lastName}`,
      firstName: data.admin.firstName,
      lastName: data.admin.lastName,
      email: data.admin.email,
      role: UserRole.ADMIN,
      dob: data.admin.dob,
      phoneNo: data.admin.phone,
      city: data.admin.city,
      state: data.admin.state,
      zipcode: data.admin.zipcode,
    };
  }
  if (data.customer) {
    return {
      id: data.customer.id,
      name: `${data.customer.firstName} ${data.customer.lastName}`,
      firstName: data.customer.firstName,
      lastName: data.customer.lastName,
      email: data.customer.email,
      role: UserRole.CUSTOMER,
      dob: data.customer.dob,
      phoneNo: data.customer.phone,
      city: data.customer.city,
      state: data.customer.state,
      zipcode: data.customer.zipcode,
    };
  }
  if (data.organizer) {
    return {
      id: data.organizer.id,
      name: `${data.organizer.firstName} ${data.organizer.lastName}`,
      firstName: data.organizer.firstName,
      lastName: data.organizer.lastName,
      email: data.organizer.email,
      role: UserRole.ORGANIZER,
      dob: data.organizer.dob,
      phoneNo: data.organizer.phone,
      city: data.organizer.city,
      state: data.organizer.state,
      zipcode: data.organizer.zipcode,
    };
  }

  return null;
}

export function useUser() {
  const user = useOptionalUser();

  if (!user) {
    throw new Error("No user found");
  }

  return {
    ...user,
  };
}

export const useAuth = () => {
  const submit = useSubmit();
  const user = useUser();

  const signOut = () => {
    return submit(null, {
      action: "/logout",
      method: "POST",
    });
  };

  return { signOut, user };
};
