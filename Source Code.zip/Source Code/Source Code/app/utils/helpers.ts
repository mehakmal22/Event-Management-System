import { type ClassValue, clsx } from "clsx";
import type * as React from "react";
import { twMerge } from "tailwind-merge";
import type { Gender } from "~/utils/prisma-enums";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export type LiteralUnion<T extends U, U = string> = T | (U & {});

export type Prettify<T> = {
  [K in keyof T]: T[K];
} & {};

export type PropsFrom<TComponent> = TComponent extends React.FC<infer Props>
  ? Props
  : TComponent extends React.Component<infer Props>
    ? Props
    : never;

export type DateToString<T> = {
  [K in keyof T]: T[K] extends Date ? string : T[K];
} & {};

/**
 * `Gender` enum label lookup
 */
export const genderLabelLookup = {
  FEMALE: "Female",
  MALE: "Male",
  OTHER: "Other",
} satisfies Record<Gender, string>;

export const toFixedDate = (date: Date | string) => {
  let _date: Date;
  if (date instanceof Date) {
    _date = date;
  } else {
    _date = new Date(date);
  }

  const fixedDate = new Date("2000-01-01T00:00:00Z");
  return new Date(
    fixedDate.getFullYear(),
    fixedDate.getMonth(),
    fixedDate.getDate(),
    _date.getHours(),
    _date.getMinutes(),
    _date.getSeconds(),
    _date.getMilliseconds(),
  );
};

export function convertToDateTime(time: string): Date {
  const now = new Date();

  const timeParts = time.split(":");
  const hour = Number.parseInt(timeParts[0], 10);
  const minutes = Number.parseInt(timeParts[1], 10);

  const date = new Date(
    now.getFullYear(),
    now.getMonth(),
    now.getDate(),
    hour,
    minutes,
  );

  return date;
}

export function formatTime(date: Date | string) {
  return new Intl.DateTimeFormat("en", {
    hour: "2-digit",
    minute: "2-digit",
  }).format(new Date(date));
}

export function convertToMantineTime(dateTimeString: string) {
  const date = new Date(dateTimeString);

  const hours = date.getHours().toString().padStart(2, "0");
  const minutes = date.getMinutes().toString().padStart(2, "0");

  return `${hours}:${minutes}`;
}
