// import { type ActionFunctionArgs, redirect } from "@remix-run/node";
// import { db } from "~/lib/db.server";

// export const loader = async () => {
//   return redirect("/organizer/events");
// };

// export const action = async ({ request }: ActionFunctionArgs) => {
//   const formData = await request.formData();

//   const eventIdToDelete = formData.get("eventId")?.toString();

//   if (!eventIdToDelete) {
//     return redirect("/organizer/events");
//   }

//   await db.$transaction(async (db) => {
//     await db.payment.deleteMany({
//       where: { eventId: eventIdToDelete },
//     });

//     await db.reservation.deleteMany({
//       where: { eventId: eventIdToDelete },
//     });

//     await db.session.deleteMany({
//       where: { eventId: eventIdToDelete },
//     });

//     await db.event.delete({
//       where: { id: eventIdToDelete },
//     });
//   });

//   return redirect("/organizer/events");
// };
