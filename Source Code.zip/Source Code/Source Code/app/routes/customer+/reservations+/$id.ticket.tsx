import { Divider } from "@mantine/core";
import { json, redirect, type LoaderFunctionArgs } from "@remix-run/node";
import { Link, useLoaderData } from "@remix-run/react";
import { ArrowLeft } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card";
import { getTicketByReservationId } from "~/lib/ticket.server";

export const loader = async ({ params }: LoaderFunctionArgs) => {
  const { id } = params;
  if (!id) {
    return redirect("/customer/reservations");
  }

  const ticket = await getTicketByReservationId(id);
  if (!ticket) {
    return redirect("/customer/reservations");
  }

  return json({
    ticket,
  });
};

export default function Ticket() {
  const { ticket } = useLoaderData<typeof loader>();

  return (
    <div className="flex flex-col gap-3">
      <Link to="/customer/reservations">
        <ArrowLeft className="w-6 h-6 hover:scale-105" />
      </Link>
      <Card className="w-full flex items-center justify-evenly p-5">
        <CardHeader className="flex items-center justify-center w-full">
          <p className="text-md font-medium leading-none mt-1 text-gray-600">
            {generateTicketNumber(ticket.id)}
          </p>
          <CardTitle className="flex items-center justify-center">
            {ticket.event.title}
          </CardTitle>
          <CardDescription className="flex items-center justify-center">
            <span>{ticket.event.description}</span>
          </CardDescription>
          <div>x {ticket.reservation!.noOfSeats}</div>
        </CardHeader>
        <Divider orientation="vertical" className="h-44" />
        <CardContent className="flex items-center justify-center gap-8 w-full">
          <div className="flex flex-col items-center justify-center space-x-2">
            <span className="text-lg font-bold">Venue</span>
            <div className="space-y-1 flex flex-col items-center justify-center mt-1">
              <p className="text-md font-medium text-muted-foreground leading-none mt-1">
                {ticket.event.venue}
              </p>
            </div>
          </div>
          <Divider orientation="vertical" className="h-24" />
        </CardContent>
      </Card>
    </div>
  );
}

function generateTicketNumber(ticketId: string): string {
  return ticketId.slice(0, 8).toUpperCase();
}
