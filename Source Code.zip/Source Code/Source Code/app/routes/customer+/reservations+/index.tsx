import type { LoaderFunctionArgs } from "@remix-run/node";
import { json, Link, useLoaderData } from "@remix-run/react";
import { ArrowUpRightIcon, CalendarCogIcon } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "~/components/ui/table";
import { getAllReservationsByCustomerID } from "~/lib/reservation.server";
import { requireUserId } from "~/lib/session.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const userId = await requireUserId(request);
  const reservations = await getAllReservationsByCustomerID(userId);

  return json({ reservations });
};

export default function Reservations() {
  const { reservations } = useLoaderData<typeof loader>();

  return (
    <div>
      <Card x-chunk="dashboard-06-chunk-0">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex flex-col justify-center gap-3">
              <CardTitle>Reservations</CardTitle>
              <CardDescription>A List of all your reservations</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {reservations.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Event</TableHead>
                  <TableHead>No of Seats</TableHead>
                  <TableHead>
                    <span className="sr-only">Actions</span>
                  </TableHead>
                  <TableHead>
                    <span className="sr-only">Actions</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {reservations.map((reservation) => (
                  <TableRow key={reservation.id}>
                    <TableCell>{reservation.event.title}</TableCell>
                    <TableCell>{reservation.noOfSeats}</TableCell>
                    <TableCell>
                      <Link
                        to={`/customer/events/${reservation.event.id}`}
                        className="flex items-center justify-center gap-2"
                      >
                        <span className="underline">View Event</span>
                        <ArrowUpRightIcon className="h-4 w-4" />
                      </Link>
                    </TableCell>
                    <TableCell>
                      <Link
                        to={`/customer/reservations/${reservation.id}/ticket`}
                      >
                        <span className="underline">View Ticket</span>
                      </Link>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <EmptyState />
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="relative block w-full rounded-lg border-2 border-dashed border-gray-300 p-12 text-center">
      <CalendarCogIcon className="mx-auto h-9 w-9 text-gray-500" />
      <span className="mt-4 block text-sm font-medium text-gray-500">
        There are no Reservations for now.
      </span>
    </div>
  );
}
