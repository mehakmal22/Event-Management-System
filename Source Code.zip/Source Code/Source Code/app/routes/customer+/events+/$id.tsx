import { Card } from "@mantine/core";
import { type LoaderFunctionArgs, json, redirect } from "@remix-run/node";
import { Link, useLoaderData } from "@remix-run/react";
import { ArrowLeftCircleIcon } from "lucide-react";
import {
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card";
import { getEventById } from "~/lib/event.server";
import { formatTime } from "~/utils/helpers";
import { formatDate } from "~/utils/misc";

export const loader = async ({ params }: LoaderFunctionArgs) => {
  if (!params.id) {
    return redirect("/customer/events");
  }
  const event = await getEventById(params.id);

  if (!event) {
    return redirect("/customer/events");
  }

  return json({
    event,
  });
};

export default function EventId() {
  const { event } = useLoaderData<typeof loader>();

  return (
    <div>
      <Card x-chunk="dashboard-06-chunk-0">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex flex-col justify-center gap-3">
              <div className="mb-2 p-1">
                <Link to="..">
                  <ArrowLeftCircleIcon className="h-6 w-6 hover:scale-110" />
                </Link>
              </div>
              <div className="flex flex-col justify-center gap-3">
                <CardTitle>Event</CardTitle>
                <CardDescription>A detailed view of the event.</CardDescription>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div
            className="overflow-hidden rounded-xl border border-gray-200 shadow-md"
            key={event.id}
          >
            <div className="flex items-center justify-between gap-x-4 border-b border-gray-900/5 p-6">
              <div className="text-lg font-medium text-gray-900 flex">
                <span>{event.title}</span>
              </div>
            </div>
            <dl className="-my-3 divide-y divide-gray-100 px-6 py-4 leading-6">
              <div className="flex justify-between gap-x-4 py-3">
                <dt className="text-gray-500">Description</dt>
                <dd className="text-gray-700">
                  <p>{event.description}</p>
                </dd>
              </div>
              <div className="flex justify-between gap-x-4 py-3">
                <dt className="text-gray-500">Start Date</dt>
                <dd className="text-gray-700">
                  <span>{formatDate(event.startDate)}</span>
                </dd>
              </div>
              <div className="flex justify-between gap-x-4 py-3">
                <dt className="text-gray-500">End Date</dt>
                <dd className="text-gray-700">
                  <span>{formatDate(event.endDate)}</span>
                </dd>
              </div>
              <div className="flex justify-between gap-x-4 py-3">
                <dt className="text-gray-500">Venue</dt>
                <dd className="text-gray-700">
                  <span>{event.venue}</span>
                </dd>
              </div>
              <div className="flex justify-between gap-x-4 py-3">
                <dt className="text-gray-500">Capacity</dt>
                <dd className="text-gray-700">
                  <span>{event.capacity}</span>
                </dd>
              </div>
              <div className="flex justify-between gap-x-4 py-3">
                <dt className="text-gray-500">Price</dt>
                <dd className="text-gray-700">
                  <span>${event.price}</span>
                </dd>
              </div>
              <div className="flex justify-between gap-x-4 py-3">
                <dt className="text-gray-500">Sessions</dt>
                <dd className="text-gray-700">
                  {event.sessions.map((session) => (
                    <dd
                      className="text-gray-700 flex flex-col gap-4 border rounded-md p-4 mb-1"
                      key={session.id}
                    >
                      <span>
                        <span className="font-bold">Title:</span>{" "}
                        {session.title}
                      </span>
                      <span>
                        <span className="font-bold">Description:</span>{" "}
                        {session.description}
                      </span>
                      <span>
                        <span className="font-bold">Date:</span>{" "}
                        {formatDate(session.date)}
                      </span>
                      <span>
                        <span className="font-bold">Timings:</span>{" "}
                        {formatTime(session.startTime)} -{" "}
                        {formatTime(session.endTime)}
                      </span>
                      <span>
                        <span className="font-bold">SpeakerName:</span>{" "}
                        {session.speakerName}
                      </span>
                    </dd>
                  ))}
                </dd>
              </div>
            </dl>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
