import { Button, Input, Select, TextInput, Textarea } from "@mantine/core";
import { DatePickerInput, MonthPickerInput } from "@mantine/dates";
import {
  type ActionFunctionArgs,
  type LoaderFunctionArgs,
  json,
  redirect,
} from "@remix-run/node";
import { Link, useFetcher, useLoaderData } from "@remix-run/react";
import { ArrowLeftCircleIcon } from "lucide-react";
import * as React from "react";
import ReactInputMask from "react-input-mask";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card";
import { getEventById } from "~/lib/event.server";
import { createReservation } from "~/lib/reservation.server";
import { useUser } from "~/utils/hooks/use-auth";
import { titleCase } from "~/utils/misc";
import { badRequest } from "~/utils/misc.server";
import { EventType, PaymentMethod } from "~/utils/prisma-enums";

export const loader = async ({ params }: LoaderFunctionArgs) => {
  if (!params.id) {
    return redirect("/customer/events");
  }

  const event = await getEventById(params.id);

  if (!event) {
    return redirect("/customer/reservations");
  }

  return json({
    event,
  });
};

type ActionData = Partial<{
  success: boolean;
  message: string;
}>;

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const { id: eventId } = params;
  if (!eventId) {
    return redirect("/customer/events");
  }

  const formData = await request.formData();

  const event = await getEventById(eventId);
  if (!event) {
    return redirect("/customer/events");
  }

  const reservationStartDate = formData.get("reservationStartDate");
  const reservationEndDate = formData.get("reservationEndDate");
  const userId = formData.get("userId");
  const paymentMethod = formData.get("paymentMethod");
  const amount = formData.get("amount");
  const noOfSeats = Number.parseInt(formData.get("noOfSeats") as string);

  event.eventType === EventType.CapacityTicketPrice &&
    (!reservationStartDate ||
    !reservationEndDate ||
    !eventId ||
    !userId ||
    !paymentMethod ||
    !amount
      ? badRequest<ActionData>({
          success: false,
          message: "All Fields are required",
        })
      : null);

  event.eventType === EventType.CapacityNoTicketNoPrice ||
    (event.eventType === EventType.NoCapacityNoTicketNoPrice &&
      (!reservationStartDate || !reservationEndDate || !eventId || !userId
        ? badRequest<ActionData>({
            success: false,
            message: "All Fields are required",
          })
        : null));

  if (event.eventType === EventType.CapacityTicketPrice) {
    await createReservation({
      noOfSeats,
      eventId: eventId.toString(),
      userId: userId!.toString(),
      paymentMethod: paymentMethod?.toString() as PaymentMethod,
      amount: Number.parseFloat(amount!.toString()) * noOfSeats,
    });
  }

  if (
    event.eventType === EventType.CapacityNoTicketNoPrice ||
    event.eventType === EventType.NoCapacityNoTicketNoPrice
  ) {
    await createReservation({
      noOfSeats,
      eventId: eventId.toString(),
      userId: userId!.toString(),
    });
  }

  return redirect("/customer/reservations");
};

export default function EventReservation() {
  const { event } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<ActionData>();

  const isSubmitting = fetcher.state !== "idle";

  const user = useUser();

  const [noOfSeats, setNoOfSeats] = React.useState<number>(1);

  const [paymentMethod, setPaymentMethod] = React.useState<PaymentMethod>(
    PaymentMethod.CREDIT_CARD,
  );

  const [cardNumber, setCardNumber] = React.useState<string>("");

  const [cardExpiry, setCardExpiry] = React.useState<Date | null>(null);
  const [cardCvv, setCardCvv] = React.useState<string>("");
  const [errors, setErrors] = React.useState<{
    cardNumber?: string;
    cardExpiry?: string;
    cardCvv?: string;
  }>({
    cardNumber: "",
    cardExpiry: "",
    cardCvv: "",
  });
  const id = React.useId();

  return (
    <div>
      <Card x-chunk="dashboard-06-chunk-0">
        <CardHeader>
          <div className="mb-2 p-1">
            <Link to="..">
              <ArrowLeftCircleIcon className="h-6 w-6 hover:scale-110" />
            </Link>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex flex-col justify-center gap-3">
              <CardTitle>Reserve</CardTitle>
              <CardDescription>Reserve your spot for the event</CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <fetcher.Form
            method="post"
            className="flex flex-col gap-4"
            onSubmit={(e) => {
              e.preventDefault();

              const formData = new FormData(e.currentTarget);

              setErrors({
                cardNumber: "",
                cardExpiry: "",
                cardCvv: "",
              });

              if (cardNumber.replace(/[_ ]/g, "").length !== 16) {
                setErrors((prevError) => ({
                  ...prevError,
                  cardNumber: "Card number must be 16 digits",
                }));
              }

              if (!cardExpiry) {
                setErrors((prevError) => ({
                  ...prevError,
                  cardExpiry: "Card expiry is required",
                }));
              }

              if (!cardCvv || cardCvv.length !== 3) {
                setErrors((prevError) => ({
                  ...prevError,
                  cardCvv: "Card CVV must be 3 digits",
                }));
              }

              if (Object.values(errors).some((error) => error !== "")) {
                return;
              }

              formData.append("eventId", event.id);
              formData.append("userId", user.id);
              if (event.price) {
                formData.append("amount", event.price!.toString());
              }
              formData.append("paymentMethod", paymentMethod);

              fetcher.submit(formData, {
                method: "post",
              });
            }}
          >
            {event.price ? (
              <div className="flex flex-col gap-2">
                <h2 className="text-sm text-gray-600">
                  <span className="font-semibold">Amount: </span>
                  <span>
                    {event.price} x {noOfSeats} = {event.price * noOfSeats}
                  </span>
                </h2>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <h2 className="text-sm text-gray-600">
                  <span className="font-semibold">Amount: </span>
                  <span>This event is free</span>
                </h2>
              </div>
            )}

            <input type="hidden" name="eventId" value={event.id} />
            <input type="hidden" name="userId" value={user.id} />
            {event.price && (
              <input type="hidden" name="amount" value={event.price} />
            )}

            <TextInput
              label="No of seats"
              name="noOfSeats"
              required={true}
              type="number"
              min={1}
              onChange={(e) => setNoOfSeats(Number.parseInt(e.target.value))}
            />

            {event.eventType === EventType.CapacityTicketPrice && (
              <>
                <Select
                  label="Payment method"
                  value={paymentMethod}
                  clearable={false}
                  onChange={(e) => setPaymentMethod(e as PaymentMethod)}
                  data={Object.values(PaymentMethod).map((method) => ({
                    label: titleCase(method.replace(/_/g, " ")),
                    value: method,
                  }))}
                />

                <Input.Wrapper
                  id={id}
                  label="Credit card number"
                  required={true}
                  error={errors.cardNumber}
                >
                  <Input
                    id={id}
                    component={ReactInputMask}
                    mask="9999 9999 9999 9999"
                    placeholder="XXXX XXXX XXXX XXXX"
                    alwaysShowMask={false}
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                  />
                </Input.Wrapper>

                <div className="flex items-center gap-4">
                  <Input.Wrapper
                    id={`${id}cvv`}
                    label="CVV"
                    required={true}
                    error={errors.cardCvv}
                  >
                    <Input
                      id={`${id}cvv`}
                      name="cvv"
                      component={ReactInputMask}
                      mask="999"
                      placeholder="XXX"
                      alwaysShowMask={false}
                      value={cardCvv}
                      onChange={(e) => setCardCvv(e.target.value)}
                    />
                  </Input.Wrapper>

                  <MonthPickerInput
                    name="expiryDate"
                    label="Expiry"
                    clearable={false}
                    placeholder="MM/YYYY"
                    required={true}
                    value={cardExpiry}
                    minDate={new Date()}
                    onChange={(e) => setCardExpiry(e)}
                    error={errors.cardExpiry}
                  />
                </div>

                <div className="flex items-center gap-4">
                  <TextInput label="City" />
                  <TextInput label="Apt no" />
                </div>

                <Textarea label="Street" />

                <div className="flex items-center gap-4">
                  <TextInput label="State" />
                  <TextInput label="Zipcode" />
                </div>
              </>
            )}
            <div className="mt-6 flex items-center gap-4 sm:justify-end">
              <Button variant="filled" type="submit" loading={isSubmitting}>
                Reserve
              </Button>
            </div>
          </fetcher.Form>
        </CardContent>
      </Card>
    </div>
  );
}
