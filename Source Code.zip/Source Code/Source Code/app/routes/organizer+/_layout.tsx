import { Button, Modal, PasswordInput, ScrollArea } from "@mantine/core";
import {
  type ActionFunctionArgs,
  type LoaderFunctionArgs,
  json,
  redirect,
} from "@remix-run/node";
import {
  Form,
  Link,
  NavLink,
  Outlet,
  useActionData,
  useLoaderData,
} from "@remix-run/react";
import {
  CalendarCogIcon,
  HomeIcon,
  LineChartIcon,
  LogOutIcon,
  Package2Icon,
  PackageIcon,
  PanelLeftIcon,
  ShoppingCartIcon,
  SquareSplitVerticalIcon,
  Users2Icon,
} from "lucide-react";
import type * as React from "react";
import { Sheet, SheetContent, SheetTrigger } from "~/components/ui/sheet";
import { db } from "~/lib/db.server";
import { getEventsByOrganizerId, getOrganizer } from "~/lib/organizer.server";
import {
  getUserId,
  getUserRole,
  isAdmin,
  isCustomer,
  requireUserId,
  validateUserRole,
} from "~/lib/session.server";
import { ResetPasswordSchema } from "~/lib/zod.schema";
import { useAuth, useUser } from "~/utils/hooks/use-auth";
import { useIsPending } from "~/utils/hooks/use-is-pending";
import { badRequest, createPasswordHash } from "~/utils/misc.server";
import { UserRole } from "~/utils/prisma-enums";
import { type inferErrors, validateAction } from "~/utils/validation";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const userId = await getUserId(request);
  const userRole = await getUserRole(request);
  await validateUserRole(request, UserRole.ORGANIZER);

  if (!userId || !userRole) {
    return redirect("/login");
  }

  const events = await getEventsByOrganizerId(userId);

  const organizer = await getOrganizer(request);

  if (await isCustomer(request)) {
    return redirect("/customer");
  }
  if (await isAdmin(request)) {
    return redirect("/admin");
  }

  return json({
    hasResetPassword: organizer!.hasResetPassword,
    events,
  });
};

interface ActionData {
  fieldErrors?: inferErrors<typeof ResetPasswordSchema>;
}

export const action = async ({ request }: ActionFunctionArgs) => {
  const userId = await requireUserId(request);
  const { fieldErrors, fields } = await validateAction(
    request,
    ResetPasswordSchema,
  );

  if (fieldErrors) {
    return badRequest<ActionData>({ fieldErrors });
  }

  const { password } = fields;

  await db.organizer.update({
    where: {
      id: userId,
    },
    data: {
      hasResetPassword: true,
      password: await createPasswordHash(password),
    },
  });

  return json({
    success: true,
  });
};

export type NavItem = {
  title: string;
  icon: React.ReactNode;
  href: string;
};

export const navItems: NavItem[] = [
  {
    title: "Events",
    icon: <CalendarCogIcon className="h-5 w-5 mr-2" />,
    href: "/organizer/events",
  },
  {
    title: "Reservations",
    icon: <SquareSplitVerticalIcon className="h-5 w-5 mr-2" />,
    href: "/organizer/reservations",
  },
];

export default function AdminLayout() {
  const user = useUser();
  const { signOut } = useAuth();

  const actionData = useActionData<ActionData>();
  const isPending = useIsPending();

  const { hasResetPassword } = useLoaderData<typeof loader>();

  return (
    <div className="flex min-h-screen w-full flex-col bg-muted/40">
      <aside className="fixed inset-y-0 left-0 z-10 hidden w-60 flex-col border-r bg-background sm:flex">
        <nav className="flex flex-col items-center gap-4 px-2 py-4">
          <div>
            <Link to="#">
              <img src="/images/logo.png" alt="logo" className="object-cover" />
            </Link>
          </div>
          <div className="flex flex-col items-center justify-center gap-4 mt-5 w-full p-2">
            {navItems.map((item) => (
              <NavLink
                key={item.href}
                to={item.href}
                className={({ isActive }) =>
                  isActive
                    ? "text-white flex rounded-lg bg-black/80 items-center p-2 w-full"
                    : "text-black flex rounded-lg hover:bg-black/80 items-center hover:text-white p-2 w-full"
                }
              >
                {item.icon}
                {item.title}
              </NavLink>
            ))}
          </div>
        </nav>
        <nav className="mt-auto flex flex-col items-center gap-4 px-2 py-4">
          <div className="flex flex-col items-center justify-center">
            <span>
              {user.firstName} {user.lastName}
            </span>
            <span>{user.email}</span>
          </div>
          <Button onClick={signOut} color="black">
            <LogOutIcon className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </nav>
      </aside>
      <div className="flex flex-col sm:gap-4 sm:py-4 sm:pl-60">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-4 border-b bg-background px-4 sm:static sm:h-auto sm:border-0 sm:bg-transparent sm:px-6">
          <Sheet>
            <SheetTrigger asChild={true}>
              <Button size="icon" variant="outline" className="sm:hidden">
                <PanelLeftIcon className="h-5 w-5" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="sm:max-w-xs">
              <nav className="grid gap-6 text-lg font-medium">
                <Link
                  to="#"
                  className="group flex h-10 w-10 shrink-0 items-center justify-center gap-2 rounded-full bg-primary text-lg font-semibold text-primary-foreground md:text-base"
                >
                  <Package2Icon className="h-5 w-5 transition-all group-hover:scale-110" />
                  <span className="sr-only">Acme Inc</span>
                </Link>
                <Link
                  to="#"
                  className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground"
                >
                  <HomeIcon className="h-5 w-5" />
                  Dashboard
                </Link>
                <Link
                  to="#"
                  className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground"
                >
                  <ShoppingCartIcon className="h-5 w-5" />
                  Orders
                </Link>
                <Link
                  to="#"
                  className="flex items-center gap-4 px-2.5 text-foreground"
                >
                  <PackageIcon className="h-5 w-5" />
                  Products
                </Link>
                <Link
                  to="#"
                  className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground"
                >
                  <Users2Icon className="h-5 w-5" />
                  Customers
                </Link>
                <Link
                  to="#"
                  className="flex items-center gap-4 px-2.5 text-muted-foreground hover:text-foreground"
                >
                  <LineChartIcon className="h-5 w-5" />
                  Settings
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
        </header>
        <main className="grid flex-1 items-start gap-4 p-4 sm:px-6 sm:py-0 md:gap-8">
          <Outlet />
        </main>
        <Modal
          closeOnClickOutside={false}
          closeOnEscape={false}
          // biome-ignore lint/suspicious/noEmptyBlockStatements: <explanation>
          onClose={() => {}}
          opened={!hasResetPassword}
          padding="lg"
          scrollAreaComponent={ScrollArea.Autosize}
          size="md"
          title="Reset Password"
          withCloseButton={false}
        >
          <Form className="flex flex-col gap-4" method="post">
            <PasswordInput
              autoFocus={true}
              error={actionData?.fieldErrors?.password}
              label="New Password"
              name="password"
              placeholder="Enter new password"
              required={true}
              type="password"
            />

            <PasswordInput
              error={actionData?.fieldErrors?.confirmPassword}
              label="Confirm new password"
              name="confirmPassword"
              placeholder="Confirm new password"
              required={true}
              type="password"
            />

            <div className="mt-4 flex items-center justify-end gap-4">
              <Button loading={isPending} type="submit">
                Reset Password
              </Button>
            </div>
          </Form>
        </Modal>
      </div>
    </div>
  );
}
