import { Button, Modal, Select, TextInput, Textarea } from "@mantine/core";
import { DatePickerInput, TimeInput } from "@mantine/dates";
import { useDisclosure } from "@mantine/hooks";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import {
  Link,
  json,
  redirect,
  useFetcher,
  useLoaderData,
} from "@remix-run/react";
import { ArrowLeftCircleIcon, Trash2Icon } from "lucide-react";
import * as React from "react";
import { redirectWithSuccess } from "remix-toast";
import { toast } from "sonner";
import { v4 as uuid } from "uuid";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card";
import { db } from "~/lib/db.server";
import { getEventById } from "~/lib/event.server";
import { requireUserId } from "~/lib/session.server";
import { EditEventSchema } from "~/lib/zod.schema";
import {
  convertToDateTime,
  convertToMantineTime,
  formatTime,
  toFixedDate,
} from "~/utils/helpers";
import { useValidateSession } from "~/utils/hooks/validate-session";
import { formatDate } from "~/utils/misc";
import { badRequest } from "~/utils/misc.server";
import { EventType } from "~/utils/prisma-enums";
import { type inferErrors, validateAction } from "~/utils/validation";

export const loader = async ({ params }: LoaderFunctionArgs) => {
  if (!params.id) {
    return redirect("/organizer/events");
  }
  const eventToEdit = await getEventById(params.id);

  if (!eventToEdit) {
    return redirect("/organizer/events");
  }

  return json({
    eventToEdit,
  });
};

interface ActionData {
  success: boolean;
  fieldErrors?: inferErrors<typeof EditEventSchema>;
}

type ISession = {
  id: string;
  title: string;
  description: string;
  date: Date;
  startTime: string;
  endTime: string;
  speakerName: string;
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const organizerId = await requireUserId(request);

  const { fieldErrors, fields } = await validateAction(
    request,
    EditEventSchema,
  );

  if (fieldErrors) {
    return badRequest<ActionData>({ success: false, fieldErrors });
  }

  await db.event.update({
    where: {
      id: fields.eventId,
    },
    data: {
      title: fields.title,
      description: fields.description,
      startDate: new Date(fields.startDate),
      endDate: new Date(fields.endDate),
      venue: fields.venue,
      capacity: Number(fields.capacity),
      price: Number(fields.price),
      organizerId: organizerId,
      sessions: {
        deleteMany: {},
        create: fields.sessions,
      },
    },
  });

  return redirectWithSuccess("/organizer/events", {
    message: "Event added",
  });
};

export default function EditEvent() {
  const { eventToEdit } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<ActionData>();

  const { validateLocalSession, validateSession } = useValidateSession();

  const [eventStartDate, setEventStartDate] = React.useState<Date | null>(
    new Date(eventToEdit.startDate),
  );
  const [eventEndDate, setEventEndDate] = React.useState<Date | null>(
    new Date(eventToEdit.endDate),
  );
  const [title, setTitle] = React.useState<string>("");
  const [description, setDescription] = React.useState<string>("");
  const [sessionDate, setSessionDate] = React.useState<Date | null>(null);
  const [startTime, setStartTime] = React.useState<string>("");
  const [endTime, setEndTime] = React.useState<string>();
  const [speakerName, setSpeakerName] = React.useState<string>();

  const _sessions = eventToEdit.sessions.map((session) => ({
    id: uuid(),
    title: session.title,
    description: session.description,
    date: new Date(session.date),
    startTime: session.startTime,
    endTime: session.endTime,
    speakerName: session.speakerName,
  }));

  console.log("Already present sessions", _sessions);

  const [sessions, setSessions] = React.useState<ISession[]>(_sessions);
  const [selectedEventType, setSelectedEventType] = React.useState<EventType>(
    eventToEdit.eventType,
  );

  const isSubmitting = fetcher.state === "submitting";

  const handleUpdateSession = (session: ISession) => {
    setSessions((prev) => {
      return prev.map((s) => {
        if (s.id === session.id) {
          return {
            ...session,
            startTime: toFixedDate(
              convertToDateTime(session.startTime),
            ).toISOString(),
            endTime: toFixedDate(
              convertToDateTime(session.endTime),
            ).toISOString(),
          };
        }

        return s;
      });
    });
  };

  const handleAddSession = () => {
    if (
      !title ||
      !description ||
      !startTime ||
      !endTime ||
      !speakerName ||
      !sessionDate
    ) {
      return;
    }

    const localSessionCheck = validateLocalSession(
      {
        date: sessionDate,
        startTime,
        endTime,
      },
      sessions,
    );

    if (!localSessionCheck.success) {
      return toast.error(localSessionCheck.error);
    }

    // console.log(
    //   "Start date",
    //   toFixedDate(convertToDateTime(startTime)).toISOString(),
    // );
    // console.log(
    //   "End date",
    //   toFixedDate(convertToDateTime(endTime)).toISOString(),
    // );

    const data = validateSession({
      title,
      description,
      date: sessionDate,
      startTime,
      endTime,
      speakerName,
    });

    if (!data.success) {
      return toast.error(data.error);
    }

    setSessions((prev) => [
      ...prev,
      {
        id: uuid(),
        title,
        description,
        date: new Date(sessionDate),
        startTime: toFixedDate(convertToDateTime(startTime)).toISOString(),
        endTime: toFixedDate(convertToDateTime(endTime)).toISOString(),
        speakerName,
      },
    ]);

    setTitle("");
    setDescription("");
    setStartTime("");
    setEndTime("");
    setSpeakerName("");
  };

  const [dateRange, setDateRange] = React.useState<Date[]>([]);

  React.useEffect(() => {
    if (eventStartDate && eventEndDate) {
      setDateRange(generateDateRange(eventStartDate, eventEndDate));
    }
  }, [eventStartDate, eventEndDate]);

  const generateDateRange = (start: Date, end: Date) => {
    const dates = [];
    const current = new Date(start);
    while (current <= end) {
      dates.push(new Date(current));
      current.setDate(current.getDate() + 1);
    }
    console.log(dates);
    return dates;
  };

  return (
    <div>
      <Card x-chunk="dashboard-06-chunk-0">
        <CardHeader>
          <div className="mb-2 p-1">
            <Link to="..">
              <ArrowLeftCircleIcon className="h-6 w-6 hover:scale-110" />
            </Link>
          </div>
          <div className="flex items-center justify-between">
            <div className="flex flex-col justify-center gap-3">
              <CardTitle>Add Event</CardTitle>
              <CardDescription>
                Add an event to your events list
              </CardDescription>
            </div>
            <div>
              <Button type="submit" color="black" form="form">
                Update Event
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="p-8 grid grid-cols-2 gap-12">
            <fetcher.Form method="POST" id="form">
              <fieldset
                disabled={isSubmitting}
                className="mt-2 flex flex-col gap-4 w-full max-w-4xl"
              >
                <input type="hidden" name="eventId" value={eventToEdit.id} />
                <input
                  type="hidden"
                  name="sessions"
                  value={JSON.stringify(sessions)}
                />
                <div className="flex flex-col gap-4">
                  <TextInput
                    label="Event Title"
                    name="title"
                    error={fetcher.data?.fieldErrors?.title}
                    defaultValue={eventToEdit.title}
                    required={true}
                    className="w-full"
                  />
                  <Textarea
                    label="Event Description"
                    name="description"
                    error={fetcher.data?.fieldErrors?.description}
                    defaultValue={eventToEdit.description}
                    required={true}
                    className="w-full"
                  />
                  <Select
                    label="Event Type"
                    name="eventType"
                    error={fetcher.data?.fieldErrors?.eventType}
                    required={true}
                    className="w-full"
                    defaultValue={eventToEdit.eventType}
                    onChange={(e) => setSelectedEventType(e as EventType)}
                    data={Object.values(EventType).map((type) => ({
                      label: type,
                      value: type,
                    }))}
                  />

                  <div className="flex gap-4 w-full">
                    <DatePickerInput
                      label="Start Date"
                      name="startDate"
                      error={fetcher.data?.fieldErrors?.startDate}
                      minDate={new Date()}
                      required={true}
                      className="w-full"
                      defaultValue={new Date(eventToEdit.startDate)}
                      onChange={(date) => setEventStartDate(date)}
                    />
                    <DatePickerInput
                      label="End Date"
                      name="endDate"
                      error={fetcher.data?.fieldErrors?.endDate}
                      minDate={new Date()}
                      required={true}
                      className="w-full"
                      defaultValue={new Date(eventToEdit.endDate)}
                      onChange={(date) => setEventEndDate(date)}
                    />
                  </div>
                  <div className="flex gap-4 w-full">
                    <TextInput
                      label="Venue"
                      name="venue"
                      error={fetcher.data?.fieldErrors?.venue}
                      defaultValue={eventToEdit.venue}
                      required={true}
                      className="w-full"
                    />
                    {(selectedEventType === EventType.CapacityNoTicketNoPrice ||
                      selectedEventType === EventType.CapacityTicketPrice) && (
                      <TextInput
                        label="Capacity"
                        name="capacity"
                        type="number"
                        error={fetcher.data?.fieldErrors?.capacity}
                        defaultValue={eventToEdit.capacity!}
                        min={1}
                        required={true}
                        className="w-full"
                      />
                    )}
                  </div>
                  {selectedEventType === EventType.CapacityTicketPrice && (
                    <TextInput
                      label="Price"
                      name="price"
                      type="number"
                      error={fetcher.data?.fieldErrors?.price}
                      defaultValue={eventToEdit.price!}
                      min={0}
                      required={true}
                      className="w-full"
                    />
                  )}
                </div>
              </fieldset>
            </fetcher.Form>

            <div className="flex flex-col gap-4">
              {sessions.length > 0 ? (
                <ol className="flex flex-col gap-2 pb-4 border-b">
                  {sessions.map((session) => (
                    <li key={session.id.toString()}>
                      <SessionRow
                        session={session}
                        sessions={sessions}
                        setSessions={setSessions}
                        onChange={(_s) => {
                          handleUpdateSession(_s);
                        }}
                      />
                    </li>
                  ))}
                </ol>
              ) : null}
              <TextInput
                name="title"
                label="Session Title"
                required={true}
                value={title}
                onChange={(e) => setTitle(e.currentTarget.value)}
              />
              <TextInput
                name="description"
                label="Session Description"
                required={true}
                value={description}
                onChange={(e) => setDescription(e.currentTarget.value)}
              />
              <TextInput
                name="speakerName"
                label="Session Speaker Name"
                required={true}
                value={speakerName}
                onChange={(e) => setSpeakerName(e.currentTarget.value)}
              />
              <Select
                label="Session Date"
                name="sessionDate"
                value={sessionDate?.toLocaleDateString()}
                onChange={(value) => {
                  console.log(value);
                  setSessionDate(new Date(value!));
                }}
                data={dateRange.map((date) => ({
                  value: new Date(date).toLocaleDateString(),
                  label: date.toLocaleDateString(),
                }))}
                disabled={dateRange.length === 0}
              />
              <div className="grid grid-cols-2 gap-4">
                <TimeInput
                  name="startTime"
                  label="Start Time"
                  value={startTime}
                  onChange={(e) => setStartTime(e.currentTarget.value)}
                />

                <TimeInput
                  name="endTime"
                  label="End Time"
                  value={endTime}
                  onChange={(e) => setEndTime(e.currentTarget.value)}
                />
              </div>

              <button
                onClick={handleAddSession}
                disabled={
                  !title ||
                  !description ||
                  !startTime ||
                  !endTime ||
                  !speakerName
                }
                className="block rounded-md bg-gray-900 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-gray-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed disabled:pointer-events-none"
              >
                Add Session
              </button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

type updateSessionProps = {
  session: ISession;
  sessions: ISession[];
  setSessions: React.Dispatch<React.SetStateAction<ISession[]>>;
  onChange: (session: ISession) => void;
};

export function SessionRow(props: updateSessionProps) {
  const { session, sessions, onChange, setSessions } = props;

  const [title, setTitle] = React.useState<string>(session.title);
  const [description, setDescription] = React.useState<string>(
    session.description,
  );
  const [speakerName, setSpeakerName] = React.useState<string>(
    session.speakerName,
  );

  const [startTime, setStartTime] = React.useState<string>(
    convertToMantineTime(session.startTime),
  );
  const [endTime, setEndTime] = React.useState<string>(
    convertToMantineTime(session.endTime),
  );

  const handleRemoveSession = (id: string) => {
    setSessions((prev) => prev.filter((session) => session.id !== id));
  };

  const [isModalOpen, handleModal] = useDisclosure(false);

  const { validateLocalSession, validateSession } = useValidateSession();

  const resetForm = () => {
    setStartTime(convertToMantineTime(session.startTime));
    setEndTime(convertToMantineTime(session.endTime));
  };

  return (
    <>
      <div className="overflow-hidden rounded-xl border border-gray-200 shadow-md">
        <div className="flex items-center justify-between gap-x-4 border-b border-gray-900/5 p-6">
          <div className="text-lg font-medium text-gray-900 flex">
            <span>{session.title}</span>
          </div>
          <div className="flex items-center justify-center gap-2">
            <Button
              color="red"
              onClick={() => handleRemoveSession(session.id.toString())}
            >
              <Trash2Icon className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <dl className="-my-3 divide-y divide-gray-100 px-6 py-4 leading-6">
          <div className="flex justify-between gap-x-4 py-3">
            <dt className="text-gray-500">Description</dt>
            <dd className="text-gray-700">
              <p>{session.description}</p>
            </dd>
          </div>
          <div className="flex justify-between gap-x-4 py-3">
            <dt className="text-gray-500">Date</dt>
            <dd className="text-gray-700">
              <p>{formatDate(session.date)}</p>
            </dd>
          </div>
          <div className="flex justify-between gap-x-4 py-3">
            <dt className="text-gray-500">Speaker Name</dt>
            <dd className="text-gray-700">
              <p>{session.speakerName}</p>
            </dd>
          </div>
          <div className="flex justify-between gap-x-4 py-3">
            <dt className="text-gray-500">Start Time</dt>
            <dd className="text-gray-700">
              <span>{formatTime(session.startTime)}</span>
            </dd>
          </div>
          <div className="flex justify-between gap-x-4 py-3">
            <dt className="text-gray-500">End Time</dt>
            <dd className="text-gray-700">
              <span>{formatTime(session.endTime)}</span>
            </dd>
          </div>
        </dl>
      </div>

      <Modal
        opened={isModalOpen}
        onClose={() => {
          resetForm();
          handleModal.close();
        }}
        title="Update Session"
        size="xl"
        centered={true}
        overlayProps={{ blur: 1.2, opacity: 0.6 }}
      >
        <div className="grid grid-cols-2 gap-4">
          <div className="flex flex-col gap-4">
            <TextInput
              name="title"
              label="Session Title"
              required={true}
              value={title}
              onChange={(e) => setTitle(e.currentTarget.value)}
            />
            <TextInput
              name="description"
              label="Session Description"
              required={true}
              value={description}
              onChange={(e) => setDescription(e.currentTarget.value)}
            />
            <TextInput
              name="speakerName"
              label="Session Speaker Name"
              required={true}
              value={speakerName}
              onChange={(e) => setSpeakerName(e.currentTarget.value)}
            />
            <div className="grid grid-cols-2 gap-4">
              <TimeInput
                name="startTime"
                label="Start Time"
                value={startTime}
                onChange={(e) => setStartTime(e.currentTarget.value)}
              />

              <TimeInput
                name="endTime"
                label="End Time"
                value={endTime}
                onChange={(e) => setEndTime(e.currentTarget.value)}
              />
            </div>

            <button
              onClick={() => {
                if (
                  !title ||
                  !description ||
                  !startTime ||
                  !endTime ||
                  !speakerName
                ) {
                  toast.error("Please fill all the fields");
                  return;
                }

                const localSessionCheck = validateLocalSession(
                  {
                    date: session.date,
                    startTime,
                    endTime,
                  },
                  sessions,
                );

                console.log("while updating", localSessionCheck);

                if (!localSessionCheck.success) {
                  return toast.error(localSessionCheck.error);
                }

                const _validateSession = validateSession({
                  date: session.date,
                  title,
                  description,
                  startTime,
                  endTime,
                  speakerName,
                });

                if (!_validateSession.success) {
                  return toast.error(_validateSession.error);
                }

                onChange({
                  id: session.id,
                  title,
                  description,
                  date: session.date,
                  startTime: toFixedDate(
                    convertToDateTime(startTime),
                  ).toISOString(),
                  endTime: toFixedDate(
                    convertToDateTime(endTime),
                  ).toISOString(),
                  speakerName,
                });

                handleModal.close();
              }}
              disabled={
                !title || !description || !startTime || !endTime || !speakerName
              }
              className="block rounded-md bg-gray-900 px-3 py-2 text-center text-sm font-semibold text-white shadow-sm hover:bg-gray-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 disabled:opacity-50 disabled:cursor-not-allowed disabled:pointer-events-none"
            >
              Update Session
            </button>
          </div>
          {sessions.length > 0 ? (
            <ol className="flex flex-col gap-2 pb-4 border-b">
              {sessions.map((session) => (
                <li key={session.id.toString()}>
                  <div className="overflow-hidden rounded-xl border border-gray-200 shadow-md">
                    <div className="flex items-center justify-between gap-x-4 border-b border-gray-900/5 p-6">
                      <div className="text-lg font-medium text-gray-900 flex">
                        <span>{session.title}</span>
                      </div>
                      <div className="flex items-center justify-center gap-2">
                        <Button
                          color="red"
                          onClick={() =>
                            handleRemoveSession(session.id.toString())
                          }
                        >
                          <Trash2Icon className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                    <dl className="-my-3 divide-y divide-gray-100 px-6 py-4 leading-6">
                      <div className="flex justify-between gap-x-4 py-3">
                        <dt className="text-gray-500">Description</dt>
                        <dd className="text-gray-700">
                          <p>{session.description}</p>
                        </dd>
                      </div>
                      <div className="flex justify-between gap-x-4 py-3">
                        <dt className="text-gray-500">Speaker Name</dt>
                        <dd className="text-gray-700">
                          <p>{session.speakerName}</p>
                        </dd>
                      </div>
                      <div className="flex justify-between gap-x-4 py-3">
                        <dt className="text-gray-500">Start Time</dt>
                        <dd className="text-gray-700">
                          <span>{formatTime(session.startTime)}</span>
                        </dd>
                      </div>
                      <div className="flex justify-between gap-x-4 py-3">
                        <dt className="text-gray-500">End Time</dt>
                        <dd className="text-gray-700">
                          <span>{formatTime(session.endTime)}</span>
                        </dd>
                      </div>
                    </dl>
                  </div>
                </li>
              ))}
            </ol>
          ) : null}
        </div>
      </Modal>
    </>
  );
}
