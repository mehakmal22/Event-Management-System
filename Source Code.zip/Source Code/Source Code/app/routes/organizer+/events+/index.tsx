import { Button, Card } from "@mantine/core";
import { type LoaderFunctionArgs, json } from "@remix-run/node";
import { Link, useLoaderData } from "@remix-run/react";
import {
  ArrowUpRightIcon,
  CalendarSearchIcon,
  PlusIcon,
  SquarePenIcon,
} from "lucide-react";
import {
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card";
import { getEventsByOrganizerId } from "~/lib/organizer.server";
import { requireUserId } from "~/lib/session.server";
import { formatDate } from "~/utils/misc";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const organizerId = await requireUserId(request);

  const events = await getEventsByOrganizerId(organizerId);

  return json({
    events,
  });
};

export default function Events() {
  const { events } = useLoaderData<typeof loader>();

  return (
    <div>
      <Card x-chunk="dashboard-06-chunk-0">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex flex-col justify-center gap-3">
              <CardTitle>Events</CardTitle>
              <CardDescription>Manage your events here.</CardDescription>
            </div>
            <div>
              <Link to="/organizer/events/new">
                <Button color="black">
                  <PlusIcon className="h-4 w-4 mr-2" />
                  Add Event
                </Button>
              </Link>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {events.length > 0 ? (
            <div className="grid grid-cols-1 gap-x-6 gap-y-8 md:grid-cols-2 px-5 lg:px-10 py-5 xl:gap-x-8">
              {events.map((event) => (
                <div
                  className="overflow-hidden rounded-xl border border-gray-200 shadow-md"
                  key={event.id}
                >
                  <div className="flex items-center justify-between gap-x-4 border-b border-gray-900/5 p-6">
                    <div className="text-lg font-medium text-gray-900 flex">
                      <span>{event.title}</span>
                    </div>
                    <div className="flex items-center justify-center gap-2">
                      <Link to={`/organizer/events/edit/${event.id}`}>
                        <Button color="gray">
                          <SquarePenIcon className="h-4 w-4" />
                        </Button>
                      </Link>
                    </div>
                  </div>
                  <dl className="-my-3 divide-y divide-gray-100 px-6 py-4 leading-6">
                    <div className="flex justify-between gap-x-4 py-3">
                      <dt className="text-gray-500">Description</dt>
                      <dd className="text-gray-700">
                        <p>{event.description}</p>
                      </dd>
                    </div>
                    <div className="flex justify-between gap-x-4 py-3">
                      <dt className="text-gray-500">Type</dt>
                      <dd className="text-gray-700">
                        <p>{event.eventType}</p>
                      </dd>
                    </div>
                    <div className="flex justify-between gap-x-4 py-3">
                      <dt className="text-gray-500">Start Date</dt>
                      <dd className="text-gray-700">
                        <span>{formatDate(event.startDate)}</span>
                      </dd>
                    </div>
                    <div className="flex justify-between gap-x-4 py-3">
                      <dt className="text-gray-500">End Date</dt>
                      <dd className="text-gray-700">
                        <span>{formatDate(event.endDate)}</span>
                      </dd>
                    </div>
                    <div className="flex justify-between gap-x-4 py-3">
                      <dt className="text-gray-500">Venue</dt>
                      <dd className="text-gray-700">
                        <span>{event.venue}</span>
                      </dd>
                    </div>
                    {event.capacity && (
                      <div className="flex justify-between gap-x-4 py-3">
                        <dt className="text-gray-500">Capacity</dt>
                        <dd className="text-gray-700">
                          <span>{event.capacity}</span>
                        </dd>
                      </div>
                    )}
                    {event.price && (
                      <div className="flex justify-between gap-x-4 py-3">
                        <dt className="text-gray-500">Price</dt>
                        <dd className="text-gray-700">${event.price}</dd>
                      </div>
                    )}
                    <div className="flex justify-between gap-x-4 py-3">
                      <dt className="text-gray-500">Sessions</dt>
                      <dd className="text-gray-700">
                        <Link
                          to={`/organizer/events/${event.id}`}
                          className="flex items-center justify-center gap-x-2 hover:gap-x-4 transition-all"
                        >
                          <span className="underline">View</span>{" "}
                          <ArrowUpRightIcon className="h-4 w-4" />
                        </Link>
                      </dd>
                    </div>
                  </dl>
                </div>
              ))}
            </div>
          ) : (
            <EmptyState />
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="relative block w-full rounded-lg border-2 border-dashed border-gray-300 p-12 text-center">
      <CalendarSearchIcon className="mx-auto h-9 w-9 text-gray-500" />
      <span className="mt-4 block text-sm font-medium text-gray-500">
        There are no events yet. Please add one.
      </span>
    </div>
  );
}
