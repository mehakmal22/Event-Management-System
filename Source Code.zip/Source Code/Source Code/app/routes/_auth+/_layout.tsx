import type { LoaderFunction } from "@remix-run/node";
import { Outlet, redirect } from "@remix-run/react";

import {
  getUserId,
  getUserRole,
  isAdmin,
  isCustomer,
  isOrganizer,
  validateUserRole,
} from "~/lib/session.server";

export const loader: LoaderFunction = async ({ request }) => {
  const userId = await getUserId(request);
  const userRole = await getUserRole(request);
  await validateUserRole(request, null);

  if (!userId || !userRole) {
    return null;
  }

  if (await isCustomer(request)) {
    return redirect("/customer");
  }
  if (await isOrganizer(request)) {
    return redirect("/organizer");
  }
  if (await isAdmin(request)) {
    return redirect("/admin");
  }
};

export default function AuthLayout() {
  return (
    <div className="h-screen w-full relative">
      <img
        alt="CM"
        className="h-full w-full object-cover absolute inset-0"
        src="https://images.unsplash.com/photo-1540575467063-178a50c2df87?q=80&w=3270&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
      />
      <div className="absolute inset-0 bg-black/70" />
      <div className="absolute inset-0 flex items-center justify-center">
        <Outlet />
      </div>
    </div>
  );
}
