import {
  Button,
  Card,
  Divider,
  PasswordInput,
  Select,
  Switch,
  TextInput,
} from "@mantine/core";
import { DatePickerInput } from "@mantine/dates";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { Form, Link, json, redirect, useActionData } from "@remix-run/react";
import { CalendarIcon, ChevronRight } from "lucide-react";
import * as React from "react";
import { Label } from "~/components/ui/label";
import {
  getCustomerByEmail,
  getCustomerByUsername,
} from "~/lib/customer.server";
import {
  createUserSession,
  getUserId,
  getUserRole,
  isAdmin,
  isCustomer,
  isOrganizer,
} from "~/lib/session.server";
import { createUser } from "~/lib/user.server";
import { CreateCustomerSchema } from "~/lib/zod.schema";
import { useIsPending } from "~/utils/hooks/use-is-pending";
import { badRequest, safeRedirect } from "~/utils/misc.server";
import { Gender, UserRole } from "~/utils/prisma-enums";
import { type inferErrors, validateAction } from "~/utils/validation";

interface ActionData {
  fieldErrors?: inferErrors<typeof CreateCustomerSchema>;
}

export type SearchParams = {
  redirectTo?: string;
};

export async function loader({ request }: LoaderFunctionArgs) {
  const userId = await getUserId(request);
  const userRole = await getUserRole(request);

  if (!userId || !userRole) {
    return null;
  }

  if (await isAdmin(request)) {
    return redirect("/admin");
  }

  if (await isCustomer(request)) {
    return redirect("/customer");
  }

  if (await isOrganizer(request)) {
    return redirect("/organizer");
  }

  return null;
}

export const action = async ({ request }: ActionFunctionArgs) => {
  const { fieldErrors, fields } = await validateAction(
    request,
    CreateCustomerSchema,
  );

  if (fieldErrors) {
    return badRequest<ActionData>({ fieldErrors });
  }

  const {
    username,
    email,
    password,
    firstName,
    lastName,
    gender,
    dob,
    phone,
    role,
    city,
    state,
    zipcode,
  } = fields;

  // biome-ignore lint/suspicious/noImplicitAnyLet: <explanation>
  let user;

  if (role === UserRole.CUSTOMER) {
    const existingCustomer = await getCustomerByEmail(email);
    if (existingCustomer) {
      return json({
        errors: {
          email: "An user already exists with this email address.",
          password: null,
        },
      });
    }

    const existingCustomerWithSameUsername =
      await getCustomerByUsername(username);
    if (existingCustomerWithSameUsername) {
      return json({
        errors: {
          username: "An user already exists with this username.",
          password: null,
        },
      });
    }

    user = await createUser({
      username,
      email,
      firstName,
      lastName,
      password,
      gender,
      dob,
      phone,
      city,
      state,
      zipcode,
      role,
    });
  }

  if (!user) {
    return json({
      errors: {
        email: "An unknown error occurred",
        password: "An unknown error occurred",
      },
    });
  }

  return createUserSession({
    request,
    userId: user.id,
    role: role as UserRole,
    redirectTo: safeRedirect(`/${role?.toLowerCase()}`),
  });
};

export default function Register() {
  const actionData = useActionData<ActionData>();
  const isPending = useIsPending();

  const [gender, setGender] = React.useState<Gender>(Gender.MALE);

  return (
    <div className="flex flex-col items-center gap-4">
      <Card
        className="w-[600px] bg-gray-100"
        padding="xl"
        radius="lg"
        shadow="xl"
        withBorder={true}
      >
        <Card.Section
          className="bg-white"
          inheritPadding={true}
          pb="sm"
          pt="xl"
        >
          <h2 className="text-center text-xl font-bold text-gray-900">
            Welcome
          </h2>
          <p className="text-center text-sm text-gray-600">
            Create an account.
          </p>
        </Card.Section>

        <Card.Section
          className="bg-white"
          inheritPadding={true}
          pt="md"
          withBorder={false}
        >
          <Divider />
        </Card.Section>

        <Card.Section
          className="rounded-b-xl bg-white"
          inheritPadding={true}
          pb="xl"
          withBorder={true}
        >
          <Form className="mt-4 flex flex-col gap-8" method="post">
            <fieldset className="grid grid-cols-2 gap-4" disabled={isPending}>
              <input type="hidden" name="role" value={UserRole.CUSTOMER} />

              <TextInput
                autoFocus={true}
                error={actionData?.fieldErrors?.firstName}
                label="First Name"
                name="firstName"
                required={true}
                withAsterisk={false}
              />
              <TextInput
                error={actionData?.fieldErrors?.lastName}
                label="Last Name"
                name="lastName"
                required={true}
                withAsterisk={false}
              />

              <TextInput
                error={actionData?.fieldErrors?.username}
                label="User Name"
                name="username"
                required={true}
                withAsterisk={false}
              />

              <Select
                name="gender"
                label="Gender"
                placeholder="Select your gender"
                error={actionData?.fieldErrors?.gender}
                value={gender}
                onChange={(val) => setGender(val as Gender)}
                data={Object.values(Gender).map((gender) => ({
                  label: gender,
                  value: gender,
                }))}
                required={true}
                withAsterisk={false}
              />

              <DatePickerInput
                clearable={true}
                defaultLevel="decade"
                dropdownType="popover"
                error={actionData?.fieldErrors?.dob}
                label="Date of birth"
                leftSection={
                  <CalendarIcon className="text-gray-400" size={14} />
                }
                leftSectionPointerEvents="none"
                maxDate={new Date()}
                name="dob"
                placeholder="Choose date of birth"
                popoverProps={{
                  withinPortal: true,
                }}
                required={true}
                valueFormat="MM-DD-YYYY"
              />

              <TextInput
                error={actionData?.fieldErrors?.phone}
                type="number"
                label="Phone number"
                name="phone"
                required={true}
                withAsterisk={false}
              />

              <TextInput
                autoComplete="email"
                error={actionData?.fieldErrors?.email}
                label="Email address"
                name="email"
                required={true}
                type="email"
                withAsterisk={false}
              />

              <PasswordInput
                error={actionData?.fieldErrors?.password}
                label="Password"
                type="password"
                name="password"
                required={true}
                withAsterisk={false}
              />

              <PasswordInput
                error={actionData?.fieldErrors?.confirmPassword}
                label="Confirm Password"
                type="password"
                name="confirmPassword"
                required={true}
                withAsterisk={false}
              />

              <TextInput
                error={actionData?.fieldErrors?.city}
                label="City"
                name="city"
                required={true}
                withAsterisk={false}
              />

              <TextInput
                error={actionData?.fieldErrors?.state}
                label="State"
                name="state"
                required={true}
                withAsterisk={false}
              />

              <TextInput
                error={actionData?.fieldErrors?.zipcode}
                label="Zipcode"
                name="zipcode"
                required={true}
                withAsterisk={false}
              />
            </fieldset>

            <div className="col-span-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Label className="text-sm" htmlFor="rememberMe">
                    Remember me
                  </Label>
                  <Switch id="rememberMe" name="rememberMe" />
                </div>
                <div>
                  <Link to="/login" className="text-sm hover:underline">
                    Have an account?
                  </Link>
                </div>
              </div>

              <Button
                className="mt-4 w-full"
                loading={isPending}
                type="submit"
                color="dark"
              >
                Continue <ChevronRight className="ml-2" size={14} />
              </Button>
            </div>
          </Form>
        </Card.Section>
      </Card>
    </div>
  );
}
