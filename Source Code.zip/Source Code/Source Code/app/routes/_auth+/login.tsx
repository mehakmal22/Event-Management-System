import {
  Button,
  Card,
  Divider,
  PasswordInput,
  Select,
  Switch,
  TextInput,
} from "@mantine/core";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { Form, Link, redirect, useActionData } from "@remix-run/react";
import { ChevronRight } from "lucide-react";
import { Label } from "~/components/ui/label";

import { verifyAdminLogin } from "~/lib/admin.server";
import { verifyCustomerLogin } from "~/lib/customer.server";
import { verifyOrganizerLogin } from "~/lib/organizer.server";

import {
  createUserSession,
  getUserId,
  getUserRole,
  isAdmin,
  isCustomer,
  isOrganizer,
} from "~/lib/session.server";
import { loginSchema } from "~/lib/zod.schema";

import { useIsPending } from "~/utils/hooks/use-is-pending";
import { badRequest, safeRedirect } from "~/utils/misc.server";
import { UserRole } from "~/utils/prisma-enums";
import { type inferErrors, validateAction } from "~/utils/validation";

interface ActionData {
  fieldErrors?: inferErrors<typeof loginSchema>;
}

export type SearchParams = {
  redirectTo?: string;
};

const userRoleRedirect = {
  [UserRole.ADMIN]: "/admin",
  [UserRole.CUSTOMER]: "/customer",
  [UserRole.ORGANIZER]: "/organizer",
};

export async function loader({ request }: LoaderFunctionArgs) {
  const userId = await getUserId(request);
  const userRole = await getUserRole(request);

  if (!userId || !userRole) {
    return null;
  }

  if (await isAdmin(request)) {
    return redirect("/admin");
  }

  if (await isOrganizer(request)) {
    return redirect("/organizer");
  }

  if (await isCustomer(request)) {
    return redirect("/customer");
  }

  return null;
}

export const action = async ({ request }: ActionFunctionArgs) => {
  const { fieldErrors, fields } = await validateAction(request, loginSchema);

  if (fieldErrors) {
    return badRequest<ActionData>({ fieldErrors });
  }

  const { credential, password, redirectTo, remember, role } = fields;
  // biome-ignore lint/suspicious/noImplicitAnyLet: <explanation>
  let user;
  if (role === UserRole.ADMIN) {
    user = await verifyAdminLogin({ credential, password });
  } else if (role === UserRole.CUSTOMER) {
    user = await verifyCustomerLogin({ credential, password });
  } else if (role === UserRole.ORGANIZER) {
    user = await verifyOrganizerLogin({ credential, password });
  }

  if (!user) {
    return badRequest<ActionData>({
      fieldErrors: {
        credential: "Invalid email or username",
        password: "Invalid password",
      },
    });
  }

  return createUserSession({
    redirectTo: safeRedirect(redirectTo || userRoleRedirect[role]),
    remember: remember === "on",
    request,
    role: role,
    userId: user.id,
  });
};

export default function Login() {
  const actionData = useActionData<ActionData>();
  const isPending = useIsPending();

  return (
    <div className="flex flex-col items-center gap-4">
      <Card
        className="w-96 bg-gray-100"
        padding="xl"
        radius="lg"
        shadow="xl"
        withBorder={true}
      >
        <Card.Section
          className="bg-white"
          inheritPadding={true}
          pb="sm"
          pt="xl"
        >
          <h2 className="text-center text-xl font-bold text-gray-900">
            Welcome
          </h2>
          <p className="text-center text-sm text-gray-600">
            Please sign in to your account.
          </p>
        </Card.Section>

        <Card.Section
          className="bg-white"
          inheritPadding={true}
          pt="md"
          withBorder={false}
        >
          <Divider />
        </Card.Section>

        <Card.Section
          className="rounded-b-xl bg-white"
          inheritPadding={true}
          pb="xl"
          withBorder={true}
        >
          <Form className="mt-8" method="post">
            <fieldset className="flex flex-col gap-6" disabled={isPending}>
              <Select
                name="role"
                label="Role"
                data={Object.values(UserRole).map((role) => ({
                  value: role,
                  label: role,
                }))}
              />
              <TextInput
                autoComplete="username"
                autoFocus={true}
                error={actionData?.fieldErrors?.credential}
                label="Username or Email address"
                name="credential"
                required={true}
                withAsterisk={false}
              />

              <PasswordInput
                autoComplete="current-password"
                error={actionData?.fieldErrors?.password}
                label="Password"
                name="password"
                required={true}
                withAsterisk={false}
              />

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Label className="text-sm" htmlFor="rememberMe">
                    Remember me
                  </Label>
                  <Switch id="rememberMe" name="rememberMe" />
                </div>
                <div>
                  <Link to="/register" className="text-sm hover:underline">
                    Don't have an account?
                  </Link>
                </div>
              </div>

              <Button
                className="mt-2"
                loading={isPending}
                type="submit"
                color="dark"
              >
                Continue <ChevronRight className="ml-2" size={14} />
              </Button>
            </fieldset>
          </Form>
        </Card.Section>
      </Card>
    </div>
  );
}
