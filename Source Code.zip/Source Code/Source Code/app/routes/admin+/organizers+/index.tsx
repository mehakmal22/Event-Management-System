import { Button } from "@mantine/core";
import { json, Link, useLoaderData } from "@remix-run/react";
import { MoreHorizontalIcon, PlusIcon, Users2Icon } from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "~/components/ui/dropdown-menu";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "~/components/ui/table";
import { getOrganizers } from "~/lib/organizer.server";
import { formatDate } from "~/utils/misc";

export const loader = async () => {
  const organizers = await getOrganizers();

  return json({ organizers });
};

export default function Organizers() {
  const { organizers } = useLoaderData<typeof loader>();

  return (
    <div>
      <Card x-chunk="dashboard-06-chunk-0">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div className="flex flex-col justify-center gap-3">
              <CardTitle>Organizers</CardTitle>
              <CardDescription>Manage your organizers here.</CardDescription>
            </div>
            <div>
              <Link to="/admin/organizers/new">
                <Button color="black">
                  <PlusIcon className="h-4 w-4 mr-2" />
                  Add Organizer
                </Button>
              </Link>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {organizers.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Name</TableHead>
                  <TableHead>Email</TableHead>
                  <TableHead>City</TableHead>
                  <TableHead>State</TableHead>
                  <TableHead>Zipcode</TableHead>
                  <TableHead>Phone No</TableHead>
                  <TableHead>DOB</TableHead>
                  <TableHead>Gender</TableHead>
                  <TableHead>
                    <span className="sr-only">Actions</span>
                  </TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {organizers.map((organizer) => (
                  <TableRow key={organizer.id}>
                    <TableCell className="font-medium">
                      {organizer.firstName} {organizer.lastName}
                    </TableCell>
                    <TableCell>{organizer.email}</TableCell>
                    <TableCell>{organizer.city}</TableCell>
                    <TableCell>{organizer.state}</TableCell>
                    <TableCell>{organizer.zipcode}</TableCell>
                    <TableCell className="hidden md:table-cell">
                      {organizer.phone}
                    </TableCell>

                    <TableCell className="hidden md:table-cell">
                      {formatDate(organizer.dob)}
                    </TableCell>
                    <TableCell className="hidden md:table-cell">
                      {organizer.gender}
                    </TableCell>
                    <TableCell>
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild={true}>
                          <Button
                            aria-haspopup="true"
                            size="icon"
                            variant="light"
                            color="black"
                          >
                            <MoreHorizontalIcon className="h-4 w-4" />
                            <span className="sr-only">Toggle menu</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          <DropdownMenuItem>
                            <Link to={`/admin/organizers/edit/${organizer.id}`}>
                              Edit
                            </Link>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <EmptyState />
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function EmptyState() {
  return (
    <div className="relative block w-full rounded-lg border-2 border-dashed border-gray-300 p-12 text-center">
      <Users2Icon className="mx-auto h-9 w-9 text-gray-500" />
      <span className="mt-4 block text-sm font-medium text-gray-500">
        There are no organizers yet. Please add one.
      </span>
    </div>
  );
}
