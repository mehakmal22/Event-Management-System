import { Button, Select, TextInput } from "@mantine/core";
import { DatePickerInput } from "@mantine/dates";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import {
  json,
  Link,
  redirect,
  useFetcher,
  useLoaderData,
} from "@remix-run/react";
import { ArrowLeftCircleIcon } from "lucide-react";
import { redirectWithSuccess } from "remix-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card";
import { db } from "~/lib/db.server";
import { getOrganizerById } from "~/lib/organizer.server";
import { EditOrganizerSchema } from "~/lib/zod.schema";
import { badRequest } from "~/utils/misc.server";
import { Gender } from "~/utils/prisma-enums";
import { type inferErrors, validateAction } from "~/utils/validation";

interface ActionData {
  success: boolean;
  fieldErrors?: inferErrors<typeof EditOrganizerSchema>;
}

export const loader = async ({ params }: LoaderFunctionArgs) => {
  if (!params.id) {
    return redirect("/admin/organizers");
  }

  const organizerToEdit = await getOrganizerById(params.id as string);

  if (!organizerToEdit) {
    return redirect("/admin/organizers");
  }

  return json({ organizerToEdit });
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { fieldErrors, fields } = await validateAction(
    request,
    EditOrganizerSchema,
  );

  if (fieldErrors) {
    return badRequest<ActionData>({ success: false, fieldErrors });
  }

  await db.organizer.update({
    where: { id: fields.organizerId },
    data: {
      firstName: fields.firstName,
      lastName: fields.lastName,
      email: fields.email,
      city: fields.city,
      state: fields.state,
      zipcode: fields.zipcode,
      phone: fields.phone,
      dob: new Date(fields.dob),
      gender: fields.gender as Gender,
    },
  });

  return redirectWithSuccess("/admin/organizers", {
    message: "Organizer updated",
  });
};

export default function NewOrganizer() {
  const { organizerToEdit } = useLoaderData<typeof loader>();

  const fetcher = useFetcher<ActionData>();

  const isSubmitting = fetcher.state === "submitting";

  return (
    <div>
      <Card x-chunk="dashboard-06-chunk-0">
        <CardHeader>
          <div className="mb-2 p-1">
            <Link to="..">
              <ArrowLeftCircleIcon className="h-6 w-6 hover:scale-110" />
            </Link>
          </div>
          <CardTitle>Edit Organizer</CardTitle>
          <CardDescription>Update the details of a organizer.</CardDescription>
        </CardHeader>
        <CardContent>
          <fetcher.Form method="POST">
            <fieldset
              disabled={isSubmitting}
              className="mt-2 flex flex-col gap-4 w-full max-w-4xl"
            >
              <div className="flex flex-col gap-4">
                <div className="flex gap-4 w-full">
                  <input
                    type="hidden"
                    name="organizerId"
                    value={organizerToEdit.id}
                  />
                  <TextInput
                    label="First Name"
                    name="firstName"
                    error={fetcher.data?.fieldErrors?.firstName}
                    defaultValue={organizerToEdit.firstName}
                    required={true}
                    className="w-full"
                  />
                  <TextInput
                    label="Last Name"
                    name="lastName"
                    error={fetcher.data?.fieldErrors?.lastName}
                    defaultValue={organizerToEdit.lastName}
                    required={true}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-4 w-full">
                  <TextInput
                    label="Email"
                    name="email"
                    type="email"
                    error={fetcher.data?.fieldErrors?.email}
                    defaultValue={organizerToEdit.email}
                    required={true}
                    className="w-full"
                  />
                  <DatePickerInput
                    label="Date of Birth"
                    name="dob"
                    error={fetcher.data?.fieldErrors?.dob}
                    defaultValue={new Date(organizerToEdit.dob)}
                    required={true}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-4 w-full">
                  <TextInput
                    label="Company Name"
                    name="companyName"
                    error={fetcher.data?.fieldErrors?.companyName}
                    defaultValue={organizerToEdit.companyName}
                    required={true}
                    className="w-full"
                  />
                  <TextInput
                    label="City"
                    name="city"
                    error={fetcher.data?.fieldErrors?.city}
                    defaultValue={organizerToEdit.city}
                    required={true}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-4 w-full">
                  <TextInput
                    label="State"
                    name="state"
                    error={fetcher.data?.fieldErrors?.state}
                    defaultValue={organizerToEdit.state}
                    required={true}
                    className="w-full"
                  />
                  <TextInput
                    label="Zipcode"
                    name="zipcode"
                    error={fetcher.data?.fieldErrors?.zipcode}
                    defaultValue={organizerToEdit.zipcode}
                    required={true}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-4 w-full">
                  <TextInput
                    label="Phone Number"
                    name="phone"
                    error={fetcher.data?.fieldErrors?.phone}
                    defaultValue={organizerToEdit.phone}
                    required={true}
                    className="w-full"
                  />
                  <Select
                    label="Gender"
                    name="gender"
                    error={fetcher.data?.fieldErrors?.gender}
                    data={Object.values(Gender).map((gender) => ({
                      label: gender,
                      value: gender,
                    }))}
                    defaultValue={organizerToEdit.gender}
                    required={true}
                    className="w-full"
                  />
                </div>
              </div>
              <div className="mt-5 flex gap-4 w-full">
                <Link to=".." className="w-full">
                  <Button
                    variant="subtle"
                    type="button"
                    disabled={isSubmitting}
                    color="red"
                    className="w-full"
                  >
                    Cancel
                  </Button>
                </Link>
                <Button
                  type="submit"
                  loading={isSubmitting}
                  color="black"
                  className="w-full"
                >
                  Update Organizer
                </Button>
              </div>
            </fieldset>
          </fetcher.Form>
        </CardContent>
      </Card>
    </div>
  );
}
