import { Button, PasswordInput, Select, TextInput } from "@mantine/core";
import { DatePickerInput } from "@mantine/dates";
import type { ActionFunctionArgs } from "@remix-run/node";
import { Link, useFetcher } from "@remix-run/react";
import { ArrowLeftCircleIcon } from "lucide-react";
import { redirectWithSuccess } from "remix-toast";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "~/components/ui/card";
import { db } from "~/lib/db.server";
import { CreateOrganizerSchema } from "~/lib/zod.schema";
import { badRequest, createPasswordHash } from "~/utils/misc.server";
import { Gender } from "~/utils/prisma-enums";
import { type inferErrors, validateAction } from "~/utils/validation";

interface ActionData {
  success: boolean;
  fieldErrors?: inferErrors<typeof CreateOrganizerSchema>;
}

export const action = async ({ request }: ActionFunctionArgs) => {
  const { fieldErrors, fields } = await validateAction(
    request,
    CreateOrganizerSchema,
  );

  if (fieldErrors) {
    return badRequest<ActionData>({ success: false, fieldErrors });
  }

  const existingOrganizer = await db.organizer.findUnique({
    where: { email: fields.email },
  });

  if (existingOrganizer) {
    return badRequest<ActionData>({
      success: false,
      fieldErrors: { email: "An Organizer already exists with this email" },
    });
  }

  const existingOrganizerWithSameUsername = await db.organizer.findUnique({
    where: { username: fields.username },
  });

  if (existingOrganizerWithSameUsername) {
    return badRequest<ActionData>({
      success: false,
      fieldErrors: {
        username: "An Organizer already exists with this username",
      },
    });
  }

  await db.organizer.create({
    data: {
      username: fields.username,
      firstName: fields.firstName,
      lastName: fields.lastName,
      email: fields.email,
      city: fields.city,
      state: fields.state,
      zipcode: fields.zipcode,
      companyName: fields.companyName,
      phone: fields.phone,
      dob: new Date(fields.dob),
      gender: fields.gender as Gender,
      password: await createPasswordHash(fields.password),
    },
  });

  return redirectWithSuccess("/admin/organizers", {
    message: "Organizer added",
  });
};

export default function NewOrganizer() {
  const fetcher = useFetcher<ActionData>();

  const isSubmitting = fetcher.state === "submitting";

  return (
    <div>
      <Card x-chunk="dashboard-06-chunk-0">
        <CardHeader>
          <div className="mb-2 p-1">
            <Link to="..">
              <ArrowLeftCircleIcon className="h-6 w-6 hover:scale-110" />
            </Link>
          </div>
          <CardTitle>Add Organizer</CardTitle>
          <CardDescription>Add a new organizer to your system.</CardDescription>
        </CardHeader>
        <CardContent>
          <fetcher.Form method="POST">
            <fieldset
              disabled={isSubmitting}
              className="mt-2 flex flex-col gap-4 w-full max-w-4xl"
            >
              <div className="flex flex-col gap-4">
                <div className="flex gap-4 w-full">
                  <TextInput
                    label="First Name"
                    name="firstName"
                    error={fetcher.data?.fieldErrors?.firstName}
                    required={true}
                    className="w-full"
                  />
                  <TextInput
                    label="Last Name"
                    name="lastName"
                    error={fetcher.data?.fieldErrors?.lastName}
                    required={true}
                    className="w-full"
                  />
                </div>
                <TextInput
                  label="Username"
                  name="username"
                  error={fetcher.data?.fieldErrors?.username}
                  required={true}
                  className="w-full"
                />
                <div className="flex gap-4 w-full">
                  <TextInput
                    label="Email"
                    name="email"
                    type="email"
                    error={fetcher.data?.fieldErrors?.email}
                    required={true}
                    className="w-full"
                  />
                  <DatePickerInput
                    label="Date of Birth"
                    name="dob"
                    error={fetcher.data?.fieldErrors?.dob}
                    required={true}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-4 w-full">
                  <PasswordInput
                    label="Password"
                    name="password"
                    error={fetcher.data?.fieldErrors?.password}
                    required={true}
                    className="w-full"
                  />
                  <PasswordInput
                    label="Confirm Password"
                    name="confirmPassword"
                    error={fetcher.data?.fieldErrors?.confirmPassword}
                    required={true}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-4 w-full">
                  <TextInput
                    label="Company Name"
                    name="companyName"
                    error={fetcher.data?.fieldErrors?.companyName}
                    required={true}
                    className="w-full"
                  />
                  <TextInput
                    label="City"
                    name="city"
                    error={fetcher.data?.fieldErrors?.city}
                    required={true}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-4 w-full">
                  <TextInput
                    label="State"
                    name="state"
                    error={fetcher.data?.fieldErrors?.state}
                    required={true}
                    className="w-full"
                  />
                  <TextInput
                    label="Zipcode"
                    name="zipcode"
                    error={fetcher.data?.fieldErrors?.zipcode}
                    required={true}
                    className="w-full"
                  />
                </div>
                <div className="flex gap-4 w-full">
                  <TextInput
                    label="Phone Number"
                    name="phone"
                    error={fetcher.data?.fieldErrors?.phone}
                    required={true}
                    className="w-full"
                  />
                  <Select
                    label="Gender"
                    name="gender"
                    error={fetcher.data?.fieldErrors?.gender}
                    data={Object.values(Gender).map((gender) => ({
                      label: gender,
                      value: gender,
                    }))}
                    required={true}
                    className="w-full"
                  />
                </div>
              </div>
              <div className="mt-5 flex gap-4 w-full">
                <Link to=".." className="w-full">
                  <Button
                    variant="subtle"
                    type="button"
                    disabled={isSubmitting}
                    color="red"
                    className="w-full"
                  >
                    Cancel
                  </Button>
                </Link>
                <Button
                  type="submit"
                  loading={isSubmitting}
                  color="black"
                  className="w-full"
                >
                  Add Organizer
                </Button>
              </div>
            </fieldset>
          </fetcher.Form>
        </CardContent>
      </Card>
    </div>
  );
}
