import { createCookieSessionStorage, redirect } from "@remix-run/node";
import { match } from "ts-pattern";
import { serverEnv } from "~/lib/env.server";
import { $path } from "remix-routes";
import { UserRole } from "~/utils/prisma-enums";
import type { Admin, Customer, Organizer } from "@prisma/client";

export const sessionStorage = createCookieSessionStorage({
  cookie: {
    httpOnly: true,
    maxAge: 0,
    name: "__conference_session",
    path: "/",
    sameSite: "lax",
    secrets: [serverEnv.SESSION_SECRET],
    secure: process.env.NODE_ENV === "production",
  },
});

export const USER_SESSION_KEY = "userId";
const USER_ROLE_KEY = "userRole";
const fourteenDaysInSeconds = 60 * 60 * 24 * 14;
const thirtyDaysInSeconds = 60 * 60 * 24 * 30;

export async function getSession(request: Request) {
  const cookie = request.headers.get("Cookie");
  return sessionStorage.getSession(cookie);
}

/**
 * Returns the userId from the session.
 */
export async function getUserId(request: Request): Promise<string | undefined> {
  const session = await getSession(request);
  const userId = session.get(USER_SESSION_KEY);
  return userId;
}

export async function requireUserId(
  request: Request,
  _redirectTo: string = new URL(request.url).pathname,
) {
  const userId = await getUserId(request);
  if (!userId) {
    throw redirect($path("/login"));
  }

  return userId;
}

export async function getAdminId(
  request: Request,
): Promise<Admin["id"] | undefined> {
  const session = await getSession(request);
  const adminId = session.get(USER_SESSION_KEY);
  return adminId;
}

export async function getCustomerId(
  request: Request,
): Promise<Customer["id"] | undefined> {
  const session = await getSession(request);
  const customerId = session.get(USER_SESSION_KEY);
  return customerId;
}

export async function getOrganizerId(
  request: Request,
): Promise<Organizer["id"] | undefined> {
  const session = await getSession(request);
  const organizerId = session.get(USER_SESSION_KEY);
  return organizerId;
}

export async function getUserRole(
  request: Request,
): Promise<UserRole | undefined> {
  const session = await getSession(request);
  const userRole = session.get(USER_ROLE_KEY);
  return userRole;
}

// export async function requireUser(
//   request: Request,
//   redirectTo: string = new URL(request.url).pathname,
// ) {
//   const userId = await requireUserId(request, redirectTo);
//   const user = await getUserById(userId);
//   if (user) {
//     return user;
//   }

//   throw await logout(request);
// }

export async function createUserSession({
  redirectTo,
  remember = false,
  request,
  role,
  userId,
}: {
  redirectTo: string;
  remember?: boolean;
  request: Request;
  role: UserRole;
  userId: string;
}) {
  const session = await getSession(request);
  session.set(USER_SESSION_KEY, userId);
  session.set(USER_ROLE_KEY, role);

  return redirect(redirectTo, {
    headers: {
      "Set-Cookie": await sessionStorage.commitSession(session, {
        maxAge: remember ? thirtyDaysInSeconds : fourteenDaysInSeconds,
      }),
    },
  });
}

export async function logout(request: Request) {
  const session = await getSession(request);

  // For some reason destroySession isn't removing session keys
  // So, unsetting the keys manually
  session.unset(USER_SESSION_KEY);
  session.unset(USER_ROLE_KEY);

  return redirect($path("/login"), {
    headers: {
      "Set-Cookie": await sessionStorage.destroySession(session),
    },
  });
}

export async function isAdmin(request: Request) {
  const session = await getSession(request);
  return session.get(USER_ROLE_KEY) === UserRole.ADMIN;
}

export async function isCustomer(request: Request) {
  const session = await getSession(request);
  return session.get(USER_ROLE_KEY) === UserRole.CUSTOMER;
}

export async function isOrganizer(request: Request) {
  const session = await getSession(request);
  return session.get(USER_ROLE_KEY) === UserRole.ORGANIZER;
}

export async function validateUserRole(
  request: Request,
  role: UserRole | null,
) {
  const existingUserRole = await getUserRole(request);

  if (!existingUserRole) {
    return redirect($path("/login"));
  }

  if (role !== null && existingUserRole === role) {
    return;
  }

  return redirectUser(existingUserRole);
}

const redirectUser = (role: UserRole) => {
  return match(role)
    .with(UserRole.ADMIN, () => {
      throw redirect("/admin");
    })
    .with(UserRole.CUSTOMER, () => {
      throw redirect("/customer");
    })
    .with(UserRole.ORGANIZER, () => {
      throw redirect("/organizer");
    })
    .exhaustive();
};
