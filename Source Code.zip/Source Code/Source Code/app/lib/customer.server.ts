import type { Customer } from "@prisma/client";
import bcrypt from "bcryptjs";
import { db } from "~/lib/db.server";
import { getCustomerId, getUserId, logout } from "~/lib/session.server";

export async function verifyCustomerLogin({
  credential,
  password,
}: {
  credential: string;
  password: string;
}) {
  const customerWithPassword = await db.customer.findFirst({
    where: {
      OR: [{ email: credential }, { username: credential }],
    },
  });

  if (!customerWithPassword || !customerWithPassword.password) {
    return null;
  }

  const isValid = await bcrypt.compare(password, customerWithPassword.password);

  if (!isValid) {
    return null;
  }

  const { password: _password, ...customerWithoutPassword } =
    customerWithPassword;

  return customerWithoutPassword;
}

export async function getCustomerById(id: Customer["id"]) {
  return db.customer.findUnique({
    where: { id },
  });
}

export async function getCustomer(request: Request) {
  const customerId = await getCustomerId(request);
  if (customerId === undefined) {
    return null;
  }

  const customer = await getCustomerById(customerId);
  if (customer) {
    return customer;
  }

  throw await logout(request);
}

export async function getOptionalCustomer(
  request: Request,
): Promise<Awaited<ReturnType<typeof getCustomerById>> | null> {
  const userId = await getUserId(request);
  if (userId === undefined) {
    return null;
  }

  const customer = await getCustomerById(userId);
  if (customer) {
    return customer;
  }

  return null;
}

export async function getCustomerByEmail(email: Customer["email"]) {
  return db.customer.findUnique({
    where: { email },
  });
}

export async function getCustomerByUsername(username: Customer["username"]) {
  return db.customer.findUnique({
    where: { username },
  });
}
