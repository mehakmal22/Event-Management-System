import type { Customer, Event, Organizer } from "@prisma/client";
import { db } from "~/lib/db.server";
import { getEventById } from "~/lib/event.server";
import { EventType, type PaymentMethod } from "~/utils/prisma-enums";

export const createReservation = ({
  noOfSeats,
  userId,
  eventId,
  paymentMethod,
  amount,
}: {
  noOfSeats: number;
  userId: Customer["id"];
  eventId: Event["id"];
  paymentMethod?: PaymentMethod;
  amount?: number;
}) => {
  return db.$transaction(async (tx) => {
    const event = await getEventById(eventId);

    if (!event) {
      throw new Error("Event not found");
    }

    // biome-ignore lint/suspicious/noImplicitAnyLet: <explanation>
    let reservation;

    if (event.eventType === EventType.CapacityTicketPrice) {
      reservation = await tx.reservation.create({
        data: {
          noOfSeats,
          userId,
          eventId,
          payment: {
            create: {
              paymentMethod: paymentMethod!,
              userId: userId,
              amount: amount!,
            },
          },
        },
      });

      await tx.ticket.create({
        data: {
          eventId,
          reservationId: reservation.id,
        },
      });
    }

    if (
      event.eventType === EventType.CapacityNoTicketNoPrice ||
      event.eventType === EventType.NoCapacityNoTicketNoPrice
    ) {
      reservation = await tx.reservation.create({
        data: {
          noOfSeats,
          userId,
          eventId,
        },
      });

      await tx.ticket.create({
        data: {
          eventId,
          reservationId: reservation.id,
        },
      });
    }

    return reservation;
  });
};

export async function getAllReservationsByCustomerID(userId: Customer["id"]) {
  return await db.reservation.findMany({
    where: {
      userId: userId,
    },
    include: {
      event: true,
    },
  });
}

export async function getAllReservations() {
  return await db.reservation.findMany({
    include: {
      event: true,
      user: true,
    },
  });
}

export async function getAllReservationsForOrganizer(userId: Organizer["id"]) {
  return await db.reservation.findMany({
    where: {
      event: {
        organizerId: userId,
      },
    },
    include: {
      event: true,
      user: true,
    },
  });
}
