import type { Event } from "@prisma/client";
import { db } from "~/lib/db.server";

export async function getEventById(id: Event["id"]) {
  return await db.event.findUnique({
    where: {
      id,
    },
    include: {
      organizer: {
        select: {
          firstName: true,
          lastName: true,
          email: true,
        },
      },
      sessions: {
        select: {
          id: true,
          title: true,
          description: true,
          speakerName: true,
          date: true,
          startTime: true,
          endTime: true,
        },
      },
    },
  });
}

export async function getAllEvents() {
  return await db.event.findMany({
    include: {
      organizer: {
        select: {
          firstName: true,
          lastName: true,
          email: true,
        },
      },
    },
    orderBy: [
      {
        startDate: "asc",
      },
    ],
  });
}
