import type { Organizer, Prisma } from "@prisma/client";
import bcrypt from "bcryptjs";
import { db } from "~/lib/db.server";
import { getOrganizerId, getUserId, logout } from "~/lib/session.server";

export async function verifyOrganizerLogin({
  credential,
  password,
}: {
  credential: string;
  password: string;
}) {
  const organizerWithPassword = await db.organizer.findFirst({
    where: {
      OR: [{ email: credential }, { username: credential }],
    },
  });

  if (!organizerWithPassword || !organizerWithPassword.password) {
    return null;
  }

  const isValid = await bcrypt.compare(
    password,
    organizerWithPassword.password,
  );

  if (!isValid) {
    return null;
  }

  const { password: _password, ...organizerWithoutPassword } =
    organizerWithPassword;

  return organizerWithoutPassword;
}

export async function getOrganizerById(id: Organizer["id"]) {
  return db.organizer.findUnique({
    where: { id },
  });
}

export async function getOrganizer(request: Request) {
  const organizerId = await getOrganizerId(request);
  if (organizerId === undefined) {
    return null;
  }

  const organizer = await getOrganizerById(organizerId);
  if (organizer) {
    return organizer;
  }

  throw await logout(request);
}

export async function getOptionalOrganizer(
  request: Request,
): Promise<Awaited<ReturnType<typeof getOrganizerById>> | null> {
  const userId = await getUserId(request);
  if (userId === undefined) {
    return null;
  }

  const organizer = await getOrganizerById(userId);
  if (organizer) {
    return organizer;
  }

  return null;
}

export async function getOrganizers() {
  return db.organizer.findMany({});
}

export async function getEventsByOrganizerId(organizerId: Organizer["id"]) {
  return db.event.findMany({
    where: {
      organizerId,
    },
  });
}
