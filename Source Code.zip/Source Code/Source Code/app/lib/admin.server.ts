import type { Admin } from "@prisma/client";
import bcrypt from "bcryptjs";
import { db } from "~/lib/db.server";
import { getAdminId, getUserId, logout } from "~/lib/session.server";

export async function verifyAdminLogin({
  credential,
  password,
}: {
  credential: string;
  password: string;
}) {
  const adminWithPassword = await db.admin.findFirst({
    where: {
      OR: [{ email: credential }, { username: credential }],
    },
  });

  if (!adminWithPassword || !adminWithPassword.password) {
    return null;
  }

  const isValid = await bcrypt.compare(password, adminWithPassword.password);

  if (!isValid) {
    return null;
  }

  const { password: _password, ...adminWithoutPassword } = adminWithPassword;

  return adminWithoutPassword;
}

export async function getAdminById(id: Admin["id"]) {
  return db.admin.findUnique({
    where: { id },
  });
}

export async function getAdmin(request: Request) {
  const adminId = await getAdminId(request);
  if (adminId === undefined) {
    return null;
  }

  const admin = await getAdminById(adminId);
  if (admin) {
    return admin;
  }

  throw await logout(request);
}

export async function getOptionalAdmin(
  request: Request,
): Promise<Awaited<ReturnType<typeof getAdminById>> | null> {
  const userId = await getUserId(request);
  if (userId === undefined) {
    return null;
  }

  const admin = await getAdminById(userId);
  if (admin) {
    return admin;
  }

  return null;
}
