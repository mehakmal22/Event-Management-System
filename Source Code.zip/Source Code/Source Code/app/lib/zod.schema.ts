import { z } from "zod";
import { UserRole } from "~/utils/prisma-enums";

export const CreateCustomerSchema = z
  .object({
    organizerId: z.string().optional(),
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    username: z.string().min(1, "Username is required"),
    email: z.string().email("Invalid email address"),
    city: z.string().min(1, "City is required"),
    state: z.string().min(1, "State is required"),
    zipcode: z.string().min(1, "Zipcode is required"),
    phone: z
      .string()
      .trim()
      .min(10, "Phone number must be atleast 10 characters"),
    dob: z.string().min(1, "Date of birth is required"),
    gender: z.string().min(1, "Gender is required"),
    password: z.string().trim().min(8, "Password must be atleast 8 characters"),
    confirmPassword: z
      .string()
      .trim()
      .min(8, "Password must be atleast 8 characters"),
    role: z.nativeEnum(UserRole, {
      errorMap: () => ({
        message: "Invalid role",
      }),
    }),
  })
  .superRefine((data, ctx) => {
    if (data.password !== data.confirmPassword) {
      return ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Passwords do not match",
        path: ["confirmPassword", "password"],
      });
    }
    return true;
  });

export const loginSchema = z.object({
  credential: z
    .union([
      z.string().min(1, "Username or Email is required"),
      z.string().email("Invalid email address"),
    ])
    .refine(
      (value) => value.trim().length > 0,
      "Username or Email is required",
    ),
  password: z.string().trim().min(8, "Password must be at least 8 characters"),
  role: z.nativeEnum(UserRole),
  redirectTo: z.string().trim().default("/"),
  remember: z.enum(["on"]).optional(),
});

export const CreateOrganizerSchema = z
  .object({
    organizerId: z.string().optional(),
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    username: z.string().min(1, "Username is required"),
    email: z.string().email("Invalid email address"),
    city: z.string().min(1, "City is required"),
    state: z.string().min(1, "State is required"),
    zipcode: z.string().min(1, "Zipcode is required"),
    companyName: z.string().min(1, "Company name is required"),
    phone: z
      .string()
      .trim()
      .min(10, "Phone number must be atleast 10 characters"),
    dob: z.string().min(1, "Date of birth is required"),
    gender: z.string().min(1, "Gender is required"),
    password: z.string().trim().min(8, "Password must be atleast 8 characters"),
    confirmPassword: z
      .string()
      .trim()
      .min(8, "Password must be atleast 8 characters"),
  })
  .superRefine((data, ctx) => {
    if (data.password !== data.confirmPassword) {
      return ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Passwords do not match",
        path: ["confirmPassword", "password"],
      });
    }
    return true;
  });

export const EditOrganizerSchema = z.object({
  organizerId: z.string().optional(),
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  username: z.string().min(1, "Username is required"),
  email: z.string().email("Invalid email address"),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  zipcode: z.string().min(1, "Zipcode is required"),
  companyName: z.string().min(1, "Company name is required"),
  phone: z
    .string()
    .trim()
    .min(10, "Phone number must be atleast 10 characters"),
  dob: z.string().min(1, "Date of birth is required"),
  gender: z.string().min(1, "Gender is required"),
});

export const ResetPasswordSchema = z
  .object({
    password: z
      .string()
      .trim()
      .min(8, "Password must be at least 8 characters"),
    confirmPassword: z
      .string()
      .trim()
      .min(8, "Password must be at least 8 characters"),
  })
  .superRefine((data, ctx) => {
    if (data.password !== data.confirmPassword) {
      return ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Passwords do not match",
        path: ["confirmPassword", "password"],
      });
    }
  });

export const CreateEventSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
  venue: z.string().min(1, "Venue is required"),
  capacity: z.string().min(1, "Capacity is required").optional(),
  price: z.string().min(1, "Price is required").optional(),
  eventType: z.string().min(1, "Event type is required"),
  sessions: z
    .string()
    .transform((value) => JSON.parse(value))
    .pipe(
      z.array(
        z.object({
          title: z.string().min(1, "Title is required"),
          description: z.string().min(1, "Description is required"),
          date: z.string().min(1, "Date is required"),
          startTime: z.string().min(1, "Start time is required"),
          endTime: z.string().min(1, "End time is required"),
          speakerName: z.string().min(1, "Speaker name is required"),
        }),
      ),
    ),
});

export const EditEventSchema = z.object({
  eventId: z.string().min(1, "Event id is required"),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  startDate: z.string().min(1, "Start date is required"),
  endDate: z.string().min(1, "End date is required"),
  venue: z.string().min(1, "Venue is required"),
  capacity: z.string().min(1, "Capacity is required").optional(),
  price: z.string().min(1, "Price is required").optional(),
  eventType: z.string().min(1, "Event type is required"),
  sessions: z
    .string()
    .transform((value) => JSON.parse(value))
    .pipe(
      z.array(
        z.object({
          title: z.string().min(1, "Title is required"),
          description: z.string().min(1, "Description is required"),
          date: z.string().min(1, "Date is required"),
          startTime: z.string().min(1, "Start time is required"),
          endTime: z.string().min(1, "End time is required"),
          speakerName: z.string().min(1, "Speaker name is required"),
        }),
      ),
    ),
});
