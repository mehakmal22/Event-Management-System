import type { z } from "zod";

import { db } from "~/lib/db.server";
import type { CreateCustomerSchema } from "~/lib/zod.schema";
import { createPasswordHash } from "~/utils/misc.server";
import { type Gender, UserRole } from "~/utils/prisma-enums";

export async function createUser(
  data: Omit<z.infer<typeof CreateCustomerSchema>, "confirmPassword">,
) {
  if (data.role === UserRole.CUSTOMER) {
    const createdUser = await db.customer.create({
      data: {
        username: data.username,
        email: data.email,
        firstName: data.firstName,
        lastName: data.lastName,
        password: await createPasswordHash(data.password),
        gender: data.gender as Gender,
        dob: data.dob,
        phone: data.phone,
        city: data.city,
        state: data.state,
        zipcode: data.zipcode,
      },
    });

    return createdUser;
  }
}
