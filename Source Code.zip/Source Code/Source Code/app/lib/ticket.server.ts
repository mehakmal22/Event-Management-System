import { db } from "~/lib/db.server";

export async function getTicketByReservationId(reservationId: string) {
  return await db.ticket.findFirst({
    where: {
      reservationId,
    },
    include: {
      event: true,
      reservation: true,
    },
  });
}
