import { ColorSchemeScript, MantineProvider } from "@mantine/core";
import "@mantine/core/styles.css";
import "@mantine/dates/styles.css";
import { ModalsProvider as MantineModalsProvider } from "@mantine/modals";
import {
  type LoaderFunctionArgs,
  type SerializeFrom,
  json,
} from "@remix-run/node";
import {
  Links,
  Meta,
  Outlet,
  Scripts,
  ScrollRestoration,
} from "@remix-run/react";
import type * as React from "react";
import { getToast } from "remix-toast";
import { Toaster } from "sonner";
import { FourOhFour } from "~/components/404";
import { GeneralErrorBoundary } from "~/components/GeneralErrorBoundary";

import { getAdmin } from "~/lib/admin.server";
import { getCustomer } from "~/lib/customer.server";
import { getOrganizer } from "~/lib/organizer.server";
import { getUserId, getUserRole } from "~/lib/session.server";
import "~/globals.css";
import { cn } from "~/utils/helpers";
import { combineHeaders } from "~/utils/misc";
import { UserRole } from "~/utils/prisma-enums";

export type RootLoaderData = SerializeFrom<typeof loader>;
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const userId = await getUserId(request);
  const userRole = await getUserRole(request);
  const { headers: toastHeaders, toast } = await getToast(request);

  const response: {
    admin: Awaited<ReturnType<typeof getAdmin>>;
    customer: Awaited<ReturnType<typeof getCustomer>>;
    organizer: Awaited<ReturnType<typeof getOrganizer>>;
    toast: Awaited<ReturnType<typeof getToast>>["toast"];
  } = {
    admin: null,
    customer: null,
    organizer: null,
    toast: toast,
  };

  if (!userId || !userRole) {
    return response;
  }

  if (userRole === UserRole.ADMIN) {
    response.admin = await getAdmin(request);
  } else if (userRole === UserRole.CUSTOMER) {
    response.customer = await getCustomer(request);
  } else if (userRole === UserRole.ORGANIZER) {
    response.organizer = await getOrganizer(request);
  }

  return json(
    { ...response, toast },
    { headers: combineHeaders(toastHeaders) },
  );
};

function Document({
  children,
  title,
}: {
  children: React.ReactNode;
  title?: string;
}) {
  return (
    <html className={cn("h-full")} lang="en">
      <head>
        {title ? <title>{title}</title> : null}
        <Meta />
        <Links />
        <ColorSchemeScript />
      </head>
      <body className="isolate h-full">
        <MantineProvider>
          <Toaster richColors={true} position="bottom-center" />
          {children}
          <ScrollRestoration />
          <Scripts />
        </MantineProvider>
      </body>
    </html>
  );
}

export default function App() {
  return (
    <Document>
      <Toaster
        closeButton={true}
        duration={3000}
        position="bottom-center"
        richColors={true}
        theme="light"
        visibleToasts={3}
      />
      <MantineModalsProvider>
        <Outlet />
      </MantineModalsProvider>
    </Document>
  );
}

export function ErrorBoundary() {
  return (
    <Document>
      <GeneralErrorBoundary
        className="max-w-full"
        statusHandlers={{
          404: () => <FourOhFour />,
        }}
      />
    </Document>
  );
}
