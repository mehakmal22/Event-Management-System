import { PrismaClient } from "@prisma/client";
import { createPasswordHash } from "~/utils/misc.server";
import { EventType, Gender } from "~/utils/prisma-enums";

const db = new PrismaClient();

async function cleanup() {
  console.time("🧹 Cleaned up the database...");
  await db.payment.deleteMany();
  await db.ticket.deleteMany();
  await db.reservation.deleteMany();
  await db.session.deleteMany();
  await db.event.deleteMany();
  await db.organizer.deleteMany();
  await db.customer.deleteMany();
  await db.admin.deleteMany();
  console.timeEnd("🧹 Cleaned up the database...");
}

async function seedData() {
  await db.admin.create({
    data: {
      email: "admin@app.com",
      firstName: "Admin",
      lastName: "User",
      city: "Admin City",
      state: "DC",
      zipcode: "12345",
      phone: "1234567890",
      dob: new Date("1980-01-01"),
      username: "admin",
      gender: Gender.MALE,
      password: await createPasswordHash("password"),
    },
  });

  await db.customer.create({
    data: {
      email: "user@app.com",
      firstName: "John",
      lastName: "Doe",
      city: "User City",
      state: "DC",
      zipcode: "12345",
      username: "user",
      password: await createPasswordHash("password"),
      gender: Gender.MALE,
      dob: new Date("1980-01-01"),
      phone: "1234567890",
    },
  });

  const organizer = await db.organizer.create({
    data: {
      email: "organizer@app.com",
      firstName: "Jane",
      lastName: "Doe",
      city: "Organizer City",
      state: "DC",
      zipcode: "12345",
      companyName: "Tech Events LLC",
      username: "organizer",
      password: await createPasswordHash("password"),
      gender: Gender.FEMALE,
      dob: new Date("1990-01-01"),
      phone: "1234567890",
    },
  });

  await db.event.create({
    data: {
      title: "Tech Conference 2024",
      description: "A conference about the latest in technology.",
      startDate: new Date("2024-09-01T09:00:00Z"),
      endDate: new Date("2024-09-01T17:00:00Z"),
      venue: "Tech Convention Center",
      eventType: EventType.CapacityNoTicketNoPrice,
      capacity: 500,
      price: 60,
      organizer: {
        connect: {
          id: organizer.id,
        },
      },
      sessions: {
        create: [
          {
            title: "Opening Keynote",
            description: "Opening remarks and keynote address.",
            date: new Date("2024-09-01"),
            startTime: new Date("2024-09-01T10:00:00Z"),
            endTime: new Date("2024-09-01T11:00:00Z"),
            speakerName: "Alice Johnson",
          },
          {
            title: "Tech Trends 2024",
            description: "Discussion on the latest tech trends.",
            date: new Date("2024-09-01"),
            startTime: new Date("2024-09-01T11:30:00Z"),
            endTime: new Date("2024-09-01T12:30:00Z"),
            speakerName: "Bob Smith",
          },
        ],
      },
    },
  });
}

async function seed() {
  console.log("🌱 Seeding...\n");

  await cleanup();

  console.time("🌱 Database has been seeded");

  await seedData();

  console.timeEnd("🌱 Database has been seeded");
}

seed()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await db.$disconnect();
  });
