declare module "remix-routes" {
  type URLSearchParamsInit = string | string[][] | Record<string, string> | URLSearchParams;
  // symbol won't be a key of SearchParams
  type IsSearchParams<T> = symbol extends keyof T ? false : true;
  
  type ExportedQuery<T> = IsSearchParams<T> extends true ? T : URLSearchParamsInit;
  

  export interface Routes {
  
    "": {
      params: never,
      query: ExportedQuery<import('app/routes/_index').SearchParams>,
    };
  
    "/": {
      params: never,
      query: ExportedQuery<import('app/root').SearchParams>,
    };
  
    "/admin": {
      params: never,
      query: ExportedQuery<import('app/routes/admin+/index').SearchParams>,
    };
  
    "/admin/events": {
      params: never,
      query: ExportedQuery<import('app/routes/admin+/events+/index').SearchParams>,
    };
  
    "/admin/events/:id": {
      params: {
        id: string | number;
      } ,
      query: ExportedQuery<import('app/routes/admin+/events+/$id').SearchParams>,
    };
  
    "/admin/organizers": {
      params: never,
      query: ExportedQuery<import('app/routes/admin+/organizers+/index').SearchParams>,
    };
  
    "/admin/organizers/edit/:id": {
      params: {
        id: string | number;
      } ,
      query: ExportedQuery<import('app/routes/admin+/organizers+/edit.$id').SearchParams>,
    };
  
    "/admin/organizers/new": {
      params: never,
      query: ExportedQuery<import('app/routes/admin+/organizers+/new').SearchParams>,
    };
  
    "/admin/reservations": {
      params: never,
      query: ExportedQuery<import('app/routes/admin+/reservations+/index').SearchParams>,
    };
  
    "/customer": {
      params: never,
      query: ExportedQuery<import('app/routes/customer+/index').SearchParams>,
    };
  
    "/customer/events": {
      params: never,
      query: ExportedQuery<import('app/routes/customer+/events+/index').SearchParams>,
    };
  
    "/customer/events/:id": {
      params: {
        id: string | number;
      } ,
      query: ExportedQuery<import('app/routes/customer+/events+/$id').SearchParams>,
    };
  
    "/customer/events/reservation/:id": {
      params: {
        id: string | number;
      } ,
      query: ExportedQuery<import('app/routes/customer+/events+/reservation.$id').SearchParams>,
    };
  
    "/customer/reservations": {
      params: never,
      query: ExportedQuery<import('app/routes/customer+/reservations+/index').SearchParams>,
    };
  
    "/customer/reservations/:id/ticket": {
      params: {
        id: string | number;
      } ,
      query: ExportedQuery<import('app/routes/customer+/reservations+/$id.ticket').SearchParams>,
    };
  
    "/login": {
      params: never,
      query: ExportedQuery<import('app/routes/_auth+/login').SearchParams>,
    };
  
    "/logout": {
      params: never,
      query: ExportedQuery<import('app/routes/_auth+/logout').SearchParams>,
    };
  
    "/organizer": {
      params: never,
      query: ExportedQuery<import('app/routes/organizer+/index').SearchParams>,
    };
  
    "/organizer/events": {
      params: never,
      query: ExportedQuery<import('app/routes/organizer+/events+/index').SearchParams>,
    };
  
    "/organizer/events/:id": {
      params: {
        id: string | number;
      } ,
      query: ExportedQuery<import('app/routes/organizer+/events+/$id').SearchParams>,
    };
  
    "/organizer/events/edit/:id": {
      params: {
        id: string | number;
      } ,
      query: ExportedQuery<import('app/routes/organizer+/events+/edit.$id').SearchParams>,
    };
  
    "/organizer/events/new": {
      params: never,
      query: ExportedQuery<import('app/routes/organizer+/events+/new').SearchParams>,
    };
  
    "/organizer/reservations": {
      params: never,
      query: ExportedQuery<import('app/routes/organizer+/reservations+/index').SearchParams>,
    };
  
    "/register": {
      params: never,
      query: ExportedQuery<import('app/routes/_auth+/register').SearchParams>,
    };
  
    "/resources/delete-event": {
      params: never,
      query: ExportedQuery<import('app/routes/resources+/delete-event').SearchParams>,
    };
  
  }

  type RoutesWithParams = Pick<
    Routes,
    {
      [K in keyof Routes]: Routes[K]["params"] extends Record<string, never> ? never : K
    }[keyof Routes]
  >;

  export type RouteId =
    | 'root'
    | 'routes/_auth+/_layout'
    | 'routes/_auth+/login'
    | 'routes/_auth+/logout'
    | 'routes/_auth+/register'
    | 'routes/_index'
    | 'routes/admin+/_layout'
    | 'routes/admin+/events+/$id'
    | 'routes/admin+/events+/index'
    | 'routes/admin+/index'
    | 'routes/admin+/organizers+/edit.$id'
    | 'routes/admin+/organizers+/index'
    | 'routes/admin+/organizers+/new'
    | 'routes/admin+/reservations+/index'
    | 'routes/customer+/_layout'
    | 'routes/customer+/events+/$id'
    | 'routes/customer+/events+/index'
    | 'routes/customer+/events+/reservation.$id'
    | 'routes/customer+/index'
    | 'routes/customer+/reservations+/$id.ticket'
    | 'routes/customer+/reservations+/index'
    | 'routes/organizer+/_layout'
    | 'routes/organizer+/events+/$id'
    | 'routes/organizer+/events+/edit.$id'
    | 'routes/organizer+/events+/index'
    | 'routes/organizer+/events+/new'
    | 'routes/organizer+/index'
    | 'routes/organizer+/reservations+/index'
    | 'routes/resources+/delete-event';

  export function $path<
    Route extends keyof Routes,
    Rest extends {
      params: Routes[Route]["params"];
      query?: Routes[Route]["query"];
    }
  >(
    ...args: Rest["params"] extends Record<string, never>
      ? [route: Route, query?: Rest["query"]]
      : [route: Route, params: Rest["params"], query?: Rest["query"]]
  ): string;

  export function $params<
    Route extends keyof RoutesWithParams,
    Params extends RoutesWithParams[Route]["params"]
  >(
      route: Route,
      params: { readonly [key: string]: string | undefined }
  ): {[K in keyof Params]: string};

  export function $routeId(routeId: RouteId): RouteId;
}