export default {
  semi: false,
  singleQuote: true,
  trailingComma: "all",
  arrowParens: "avoid",
  plugins: ["prettier-plugin-tailwindcss"],
};
